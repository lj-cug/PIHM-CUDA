		/* river_d related arguments */
		river_d_attrib_riverbc_type,                                /* River attribute */
		river_d_topo_area, river_d_topo_x, river_d_topo_y,
		river_d_topo_zmin, river_d_topo_zmax, river_d_topo_zbed,
		river_d_topo_node_zmax, river_d_topo_dist_left,
		river_d_topo_dist_right,                      /* River topography parameters */
		river_d_ws_stage, river_d_ws_gw,              /* River water states */
		&river_d_wf_rivflow[NUM_RIVFLX],              /* River water fluxes */
		river_d_shp_depth, river_d_shp_intrpl_ord, river_d_shp_coeff,
		river_d_shp_length, river_d_shp_width,        /* River shape parameters */
		river_d_matl_rough, river_d_matl_cwr, river_d_matl_ksath,
		river_d_matl_ksatv, river_d_matl_bedthick, river_d_matl_porosity,
		river_d_matl_smcmin,                            /* River mathmatic modeling parameters */
		river_d_bc_head, river_d_bc_flux,               /* River boundary conditions */
		river_d_ind, river_d_leftele, river_d_rightele,
		river_d_fromnode, river_d_tonode, river_d_down  /* River geometric numbers */