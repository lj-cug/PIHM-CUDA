/* river_d related arguments */           
    int *river_d_attrib_riverbc_type,    /* River attribute */
    double *river_d_topo_area, double *river_d_topo_x, double *river_d_topo_y,                 
    double *river_d_topo_zmin,double *river_d_topo_zmax, double *river_d_topo_zbed,                            
    double *river_d_topo_node_zmax, double *river_d_topo_dist_left, 
	double *river_d_topo_dist_right,                  /* River topography parameters */   
    double *river_d_ws_stage, double *river_d_ws_gw,  /* River water states */
    double *river_d_wf_rivflow[NUM_RIVFLX],           /* River water fluxes */   
    double *river_d_shp_depth, int    *river_d_shp_intrpl_ord,  double *river_d_shp_coeff,     
    double *river_d_shp_length, double *river_d_shp_width,       /* River shape parameters */     
    double *river_d_matl_rough, double *river_d_matl_cwr, double *river_d_matl_ksath,         
    double *river_d_matl_ksatv, double *river_d_matl_bedthick, double *river_d_matl_porosity,     
    double *river_d_matl_smcmin,     /* River mathmatic modeling parameters */	
    double *river_d_bc_head, double *river_d_bc_flux,  /* River boundary conditions */  
    int *river_d_ind, int *river_d_leftele, int *river_d_rightele,      
    int *river_d_fromnode, int *river_d_tonode, int *river_d_down  /* River geometric numbers */