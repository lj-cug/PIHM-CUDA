		/* elem_d related arguments */
		elem_d_attrib_soil_type, elem_d_attrib_lc_type,
		&elem_d_attrib_bc_type[NUM_EDGE], elem_d_attrib_meteo_type,
		elem_d_attrib_lai_type,                                         /* Element attribute */
		elem_d_topo_area, elem_d_topo_x, elem_d_topo_y,
		elem_d_topo_zmin, elem_d_topo_zmax,
		&elem_d_topo_edge[NUM_EDGE], &elem_d_topo_nabrdist[NUM_EDGE],
		&elem_d_topo_nabr_x[NUM_EDGE], &elem_d_topo_nabr_y[NUM_EDGE],  /* Topography parameters */
		elem_d_soil_depth, elem_d_soil_ksath, elem_d_soil_ksatv,
		elem_d_soil_kinfv, elem_d_soil_dinf, elem_d_soil_alpha,
		elem_d_soil_beta, elem_d_soil_porosity, elem_d_soil_smcmax,
		elem_d_soil_smcmin, elem_d_soil_smcwlt, elem_d_soil_smcref,
		elem_d_soil_dmac, elem_d_soil_kmach, elem_d_soil_kmacv,
		elem_d_soil_areafv, elem_d_soil_areafh,                     /* Soil parameters */
		elem_d_lc_shdfac, elem_d_lc_shdmin, elem_d_lc_shdmax,
		elem_d_lc_laimin, elem_d_lc_laimax, elem_d_lc_snup,
		elem_d_lc_cfactr, elem_d_lc_emissmax, elem_d_lc_emissmin,
		elem_d_lc_albedomax, elem_d_lc_albedomin, elem_d_lc_z0max,
		elem_d_lc_z0min, elem_d_lc_rough, elem_d_lc_cmcfactr,
		elem_d_lc_bare, elem_d_lc_isurban,                         /* Land cover parameters */
		elem_d_epc_rsmin, elem_d_epc_rgl, elem_d_epc_hs,
		elem_d_epc_topt, elem_d_epc_rsmax,                        /* Ecophysiological parameters */
		elem_d_ps_rzd, elem_d_ps_rc, elem_d_ps_pc,
		elem_d_ps_proj_lai, elem_d_ps_rcs, elem_d_ps_rct,
		elem_d_ps_rcq, elem_d_ps_rcsoil, elem_d_ps_albedo,
		elem_d_ps_zlvl, elem_d_ps_zlvl_wind, elem_d_ps_sfcspd,
		elem_d_ps_rh, elem_d_ps_sfcprs,                           /* Physical states */
		elem_d_ws_surf, elem_d_ws_unsat, elem_d_ws_gw, elem_d_ws_sneqv,
		elem_d_ws_cmcmax, elem_d_ws_cmc, elem_d_ws_surfh,      /* Water states */
		elem_d_ws0_surf, elem_d_ws0_unsat, elem_d_ws0_gw,
		elem_d_ws0_sneqv, elem_d_ws0_cmcmax,
		elem_d_ws0_cmc, elem_d_ws0_surfh,                         /* Initial Water states */
		&elem_d_wf_ovlflow[NUM_EDGE], &elem_d_wf_subsurf[NUM_EDGE],
		elem_d_wf_prcp, elem_d_wf_pcpdrp, elem_d_wf_infil,
		elem_d_wf_rechg, elem_d_wf_drip, elem_d_wf_edir,
		elem_d_wf_ett, elem_d_wf_ec, elem_d_wf_etp,
		elem_d_wf_eta, elem_d_wf_edir_surf, elem_d_wf_edir_unsat,
		elem_d_wf_edir_gw, elem_d_wf_ett_unsat, elem_d_wf_ett_gw,
		elem_d_wf_esnow,          /* Water fluxes */
		elem_d_es_sfctmp,         /* Energy states */
		elem_d_ef_soldn,          /* Energy fluxes */
		&elem_d_bc_head[NUM_EDGE], &elem_d_bc_flux[NUM_EDGE],       /* Boundary conditions */
		&elem_d_node[NUM_EDGE], &elem_d_nabr[NUM_EDGE], elem_d_ind  /* Elements' geometric numbers */