#include "pihm.h"
#include "pihm.cuh"

cudaError_t FreeMem_cuda(pihm_struct_d pihm_d)
{
	int             i;
	cudaError_t cudaStatus;

// --------------- Basin Element ---------------------
	/* Element geometrics */
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaFree(elem_d_node[i]);
		cudaStatus = cudaFree(elem_d_nabr[i]);	
	}
	cudaStatus = cudaFree(elem_d_ind);

	/* Element attribute */
	for (i = 0; i < NUM_EDGE; i++)
		cudaStatus = cudaFree(elem_d_attrib.bc_type[i]);



	/* Topography parameters */
	cudaStatus = cudaFree(elem_d_topo.area);
	cudaStatus = cudaFree(elem_d_topo.x);
	cudaStatus = cudaFree(elem_d_topo.y);
	cudaStatus = cudaFree(elem_d_topo.zmin);
	cudaStatus = cudaFree(elem_d_topo.zmax);
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaFree(elem_d_topo.edge[i]);
		cudaStatus = cudaFree(elem_d_topo.nabrdist[i]);
		cudaStatus = cudaFree(elem_d_topo.nabr_x[i]);
		cudaStatus = cudaFree(elem_d_topo.nabr_y[i]);
	}

	/* Soil parameters  soil */
	cudaStatus = cudaFree(elem_d_soil.depth);
	cudaStatus = cudaFree(elem_d_soil.ksath);
	cudaStatus = cudaFree(elem_d_soil.dinf);
	cudaStatus = cudaFree(elem_d_soil.dmac);
	cudaStatus = cudaFree(elem_d_soil.kmach);
	cudaStatus = cudaFree(elem_d_soil.areafv);
	cudaStatus = cudaFree(elem_d_soil.porosity);

	/* Land cover parameters */
	cudaStatus = cudaFree(elem_d_lc.rough);




	/* Physical states  ps */
	cudaStatus = cudaFree(elem_d_ps.rzd);





	/* Water states  ws */
	cudaStatus = cudaFree(elem_d_ws.surf);
	cudaStatus = cudaFree(elem_d_ws.unsat);
	cudaStatus = cudaFree(elem_d_ws.gw);
	cudaStatus = cudaFree(elem_d_ws.sneqv);
	cudaStatus = cudaFree(elem_d_ws.cmcmax);
	cudaStatus = cudaFree(elem_d_ws.cmc);
	cudaStatus = cudaFree(elem_d_ws.surfh);
	/* Water fluxes  ws0 */
	cudaStatus = cudaFree(elem_d_ws0.surf);

	/* Water fluxes  wf */
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaFree(elem_d_wf.ovlflow[i]);
		cudaStatus = cudaFree(elem_d_wf.subsurf[i]);
	}
	cudaStatus = cudaFree(elem_d_wf.prcp);
	cudaStatus = cudaFree(elem_d_wf.pcpdrp);
	cudaStatus = cudaFree(elem_d_wf.infil);
	cudaStatus = cudaFree(elem_d_wf.rechg);
	cudaStatus = cudaFree(elem_d_wf.drip);
	cudaStatus = cudaFree(elem_d_wf.edir);
	cudaStatus = cudaFree(elem_d_wf.ett);
	cudaStatus = cudaFree(elem_d_wf.ec);
	cudaStatus = cudaFree(elem_d_wf.etp);
	cudaStatus = cudaFree(elem_d_wf.eta);
	cudaStatus = cudaFree(elem_d_wf.edir_surf);
	cudaStatus = cudaFree(elem_d_wf.edir_unsat);
	cudaStatus = cudaFree(elem_d_wf.edir_gw);
	cudaStatus = cudaFree(elem_d_wf.ett_unsat);
	cudaStatus = cudaFree(elem_d_wf.ett_gw);
	cudaStatus = cudaFree(elem_d_wf.esnow);

	/* Boundary conditions */
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaFree(elem_d_bc.head[i]);
		cudaStatus = cudaFree(elem_d_bc.flux[i]);
	}

	if (cudaStatus != cudaSuccess) {
		fprintf(stderr, "Element: cudaFree failed! Check Free_CUDA ?\n");
		exit(cudaStatus);
	}
//------------- River Segments -------------------
		/* River attribute */
		cudaStatus = cudaFree(river_d.attrib.riverbc_type);

		/* River topography parameters */
		cudaStatus = cudaFree(river_d.topo.area);
		//cudaStatus = cudaFree(river_d.topo.x);
		//cudaStatus = cudaFree(river_d.topo.y);
		cudaStatus = cudaFree(river_d.topo.zmin);
		cudaStatus = cudaFree(river_d.topo.zmax);
		cudaStatus = cudaFree(river_d.topo.zbed);
		//cudaStatus = cudaFree(river_d.topo.node_zmax);
		cudaStatus = cudaFree(river_d.topo.dist_left);
		cudaStatus = cudaFree(river_d.topo.dist_right);

		/* River water states */
		cudaStatus = cudaFree(river_d.ws.stage);
		cudaStatus = cudaFree(river_d.ws.gw);

		/* River water fluxes */
		for (i = 0; i < NUM_RIVFLX; i++)
			cudaStatus = cudaFree(river_d.wf.rivflow[i]);

		/* River shape parameters */
		cudaStatus = cudaFree(river_d.shp.depth);
		cudaStatus = cudaFree(river_d.shp.intrpl_ord);
		cudaStatus = cudaFree(river_d.shp.coeff);
		cudaStatus = cudaFree(river_d.shp.length);
		cudaStatus = cudaFree(river_d.shp.width);

		/* matl_struct_d */
		cudaStatus = cudaFree(river_d.matl.rough);
		cudaStatus = cudaFree(river_d.matl.cwr);
		cudaStatus = cudaFree(river_d.matl.ksath);
		//cudaStatus = cudaFree(river_d.matl.ksatv);
		//cudaStatus = cudaFree(river_d.matl.bedthick);
		cudaStatus = cudaFree(river_d.matl.porosity);
		//cudaStatus = cudaFree(river_d.matl.smcmin);

		/* River boundary conditions */
		cudaStatus = cudaFree(river_d.bc.head);
		cudaStatus = cudaFree(river_d.bc.flux);








		// check the CUDA allocation status
		cudaStatus = cudaSetDevice(0);
		if (cudaStatus != cudaSuccess) {
			fprintf(stderr, "River: cudaFree failed! Check Free_CUDA ?\n");
			exit(cudaStatus);
		}
		return(cudaStatus);
}