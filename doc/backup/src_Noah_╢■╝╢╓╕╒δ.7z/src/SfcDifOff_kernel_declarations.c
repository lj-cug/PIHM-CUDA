int      *elem_d_lc_isurban,
realtype *elem_d_ps_ch,
realtype *elem_d_ps_cm,
realtype *elem_d_ps_czil,
realtype *elem_d_ps_sfcspd,
realtype *elem_d_ps_z0,
realtype *elem_d_ps_zlvl,
realtype *elem_d_ps_zlvl_wind




