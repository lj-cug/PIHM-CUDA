int *elem_d_ps_nsoil,
realtype *elem_d_wf_runoff3,
realtype *elem_d_soil_smcmin,
realtype *elem_d_soil_smcmax,
realtype **elem_d_ps_sldpth,
realtype **elem_d_wf_et,
realtype **elem_d_wf_runoff2_lyr,
realtype **elem_d_wf_smflxv,
realtype **elem_d_ws_sh2o,
realtype **elem_d_ws_smc,
realtype **elem_d_ps_satdpth,
realtype **elem_d_ps_zsoil




