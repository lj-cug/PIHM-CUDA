int *elem_d_ps_nsoil,
realtype *elem_d_wf_infil,
realtype *elem_d_wf_edir,
realtype *elem_d_ps_fcr,
realtype *elem_d_ps_frzx,
realtype *elem_d_soil_alpha,
realtype *elem_d_soil_beta,
realtype *elem_d_soil_ksatv,
realtype *elem_d_soil_smcmin,
realtype *elem_d_soil_smcmax,
realtype **elem_d_wf_runoff2_lyr,
realtype **elem_d_wf_et,
realtype **elem_d_ws_sh2o,
realtype **elem_d_ps_zsoil


