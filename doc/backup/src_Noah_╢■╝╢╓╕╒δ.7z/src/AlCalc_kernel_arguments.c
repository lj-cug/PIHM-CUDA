elem_d_ps_alb,
elem_d_ps_albedo,
elem_d_ps_embrd,
elem_d_ps_emissi,
elem_d_ps_lvcoef,
elem_d_ps_snoalb,
elem_d_ps_sncovr,
elem_d_ps_snotime1