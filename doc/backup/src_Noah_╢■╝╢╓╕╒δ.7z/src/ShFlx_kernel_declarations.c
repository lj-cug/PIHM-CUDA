int *elem_d_lc_isurban,
int *elem_d_ps_nsoil,
realtype *elem_d_ef_ssoil,
realtype *elem_d_soil_alpha,
realtype *elem_d_soil_beta,
realtype *elem_d_soil_csoil,
realtype *elem_d_soil_quartz,
realtype *elem_d_soil_smcmin,
realtype *elem_d_soil_smcmax,
realtype *elem_d_ps_tbot,
realtype *elem_d_ps_zbot,
realtype *elem_d_es_t1,
realtype **elem_d_es_stc,
realtype **elem_d_ps_zsoil,
realtype **elem_d_ws_smc,
realtype **elem_d_ws_sh2o








