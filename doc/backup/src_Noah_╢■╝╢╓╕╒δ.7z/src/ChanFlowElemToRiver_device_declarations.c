realtype *elem_d_topo_zmin,
realtype *elem_d_ws_gw,
realtype *river_d_matl_ksath,
realtype *river_d_shp_length,
realtype *river_d_topo_zbed,
realtype *river_d_ws_stage


