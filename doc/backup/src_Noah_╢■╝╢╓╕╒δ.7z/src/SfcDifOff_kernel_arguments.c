elem_d_lc_isurban,
elem_d_ps_ch,
elem_d_ps_cm,
elem_d_ps_czil,
elem_d_ps_sfcspd,
elem_d_ps_z0,
elem_d_ps_zlvl,
elem_d_ps_zlvl_wind