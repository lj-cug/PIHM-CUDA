realtype *elem_d_lc_shdfac,
realtype *elem_d_soil_smcdry,
realtype *elem_d_soil_smcmax,
realtype *elem_d_ps_fxexp,
realtype *elem_d_wf_edir,
realtype *elem_d_wf_etp,
realtype **elem_d_ws_sh2o