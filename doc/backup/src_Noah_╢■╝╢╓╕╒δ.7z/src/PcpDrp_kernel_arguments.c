elem_d_lc_shdfac,
elem_d_wf_drip,
elem_d_wf_ec,
elem_d_wf_pcpdrp,
elem_d_ws_cmc,
elem_d_ws_cmcmax