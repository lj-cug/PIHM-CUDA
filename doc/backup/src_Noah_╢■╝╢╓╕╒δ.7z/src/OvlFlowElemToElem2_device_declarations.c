realtype *elem_d_topo_zmax,
realtype *elem_d_lc_rough,
realtype *elem_d_ws_surfh,
realtype *elem_d_topo_nabrdist2,
realtype *elem_d_topo_edge2