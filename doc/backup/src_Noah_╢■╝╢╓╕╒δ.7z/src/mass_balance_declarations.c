realtype *elem_d_topo_area,
realtype *elem_d_ws_gw,
realtype *elem_d_ws_unsat,
realtype *elem_d_ws0_gw,
realtype *elem_d_ws0_unsat,
realtype *elem_d_soil_depth,
realtype *elem_d_soil_porosity,
realtype *elem_d_wf_infil,
realtype *elem_d_wf_edir_unsat,
realtype *elem_d_wf_edir_gw,
realtype *elem_d_wf_ett_unsat,
realtype *elem_d_wf_ett_gw,
realtype *elem_d_wf_subsurf0,
realtype *elem_d_wf_subsurf1,
realtype *elem_d_wf_subsurf2



