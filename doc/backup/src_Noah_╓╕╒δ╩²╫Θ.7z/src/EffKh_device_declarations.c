realtype *elem_d_soil_areafv,
realtype *elem_d_soil_depth,
realtype *elem_d_soil_dmac,
realtype *elem_d_soil_kmach,
realtype *elem_d_soil_ksath




