int *elem_d_ps_nsoil,
realtype *elem_d_wf_runoff3,
realtype *elem_d_soil_smcmin,
realtype *elem_d_soil_smcmax,
realtype *elem_d_ps_sldpth[MAXLYR],
realtype *elem_d_wf_et[MAXLYR],
realtype *elem_d_wf_runoff2_lyr[MAXLYR],
realtype *elem_d_wf_smflxv[MAXLYR],
realtype *elem_d_ws_sh2o[MAXLYR],
realtype *elem_d_ws_smc[MAXLYR],
realtype *elem_d_ps_satdpth[MAXLYR],
realtype *elem_d_ps_zsoil[MAXLYR]




