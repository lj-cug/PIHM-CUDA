elem_d_soil_areafv,
elem_d_soil_depth,
elem_d_soil_dmac,
elem_d_soil_kmach,
elem_d_soil_ksath