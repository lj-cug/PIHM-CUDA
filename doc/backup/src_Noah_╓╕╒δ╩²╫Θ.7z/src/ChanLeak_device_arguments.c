river_d_topo_zbed,
river_d_topo_zmin,
river_d_ws_gw,
river_d_ws_stage,
river_d_shp_length,
river_d_shp_width,
river_d_matl_bedthick,
river_d_matl_ksatv