realtype *elem_d_soil_areafh,
realtype *elem_d_soil_kinfv,
realtype *elem_d_soil_kmacv