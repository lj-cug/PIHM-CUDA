elem_d_soil_alpha,
elem_d_soil_beta,
elem_d_soil_ksatv,
elem_d_soil_smcmin,
elem_d_soil_smcmax