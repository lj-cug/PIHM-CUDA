realtype *river_d_topo_zbed,
realtype *river_d_topo_zmin,
realtype *river_d_ws_gw,
realtype *river_d_ws_stage,
realtype *river_d_shp_length,
realtype *river_d_shp_width,
realtype *river_d_matl_bedthick,
realtype *river_d_matl_ksatv
