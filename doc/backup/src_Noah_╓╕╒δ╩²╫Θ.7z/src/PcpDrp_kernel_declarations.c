realtype *elem_d_lc_shdfac,
realtype *elem_d_wf_drip,
realtype *elem_d_wf_ec,
realtype *elem_d_wf_pcpdrp,
realtype *elem_d_ws_cmc,
realtype *elem_d_ws_cmcmax