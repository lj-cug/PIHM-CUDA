int      *elem_d_ps_nsoil = pihm_d->elem_d_ps_nsoil;
int      *elem_d_ps_nwtbl = pihm_d->elem_d_ps_nwtbl;
realtype *elem_d_ps_fcr = pihm_d->elem_d_ps_fcr;
realtype *elem_d_ps_frzx = pihm_d->elem_d_ps_frzx;
realtype *elem_d_soil_alpha = pihm_d->elem_d_soil_alpha;
realtype *elem_d_soil_beta = pihm_d->elem_d_soil_beta;
realtype *elem_d_soil_ksatv = pihm_d->elem_d_soil_ksatv;
realtype *elem_d_soil_smcmin = pihm_d->elem_d_soil_smcmin;
realtype *elem_d_soil_smcmax = pihm_d->elem_d_soil_smcmax;
realtype *elem_d_wf_infil = pihm_d->elem_d_wf_infil;
realtype *elem_d_wf_edir = pihm_d->elem_d_wf_edir;
realtype *elem_d_wf_runoff3 = pihm_d->elem_d_wf_runoff3;
realtype *elem_d_ws_gw = pihm_d->elem_d_ws_gw;
realtype	*elem_d_wf_et[] = {pihm_d->elem_d_wf_et[0], pihm_d->elem_d_wf_et[1], pihm_d->elem_d_wf_et[2],
	pihm_d->elem_d_wf_et[3], pihm_d->elem_d_wf_et[4], pihm_d->elem_d_wf_et[5], pihm_d->elem_d_wf_et[6],
	pihm_d->elem_d_wf_et[7], pihm_d->elem_d_wf_et[8], pihm_d->elem_d_wf_et[9], pihm_d->elem_d_wf_et[10]};	
realtype *elem_d_wf_smflxv[] = {pihm_d->elem_d_wf_smflxv[0], pihm_d->elem_d_wf_smflxv[1], pihm_d->elem_d_wf_smflxv[2],
	pihm_d->elem_d_wf_smflxv[3], pihm_d->elem_d_wf_smflxv[4], pihm_d->elem_d_wf_smflxv[5], pihm_d->elem_d_wf_smflxv[6],
	pihm_d->elem_d_wf_smflxv[7], pihm_d->elem_d_wf_smflxv[8], pihm_d->elem_d_wf_smflxv[9], pihm_d->elem_d_wf_smflxv[10]};
realtype *elem_d_wf_runoff2_lyr[] = {pihm_d->elem_d_wf_runoff2_lyr[0],pihm_d->elem_d_wf_runoff2_lyr[1],pihm_d->elem_d_wf_runoff2_lyr[2], pihm_d->elem_d_wf_runoff2_lyr[3], pihm_d->elem_d_wf_runoff2_lyr[4], pihm_d->elem_d_wf_runoff2_lyr[5],pihm_d->elem_d_wf_runoff2_lyr[6], pihm_d->elem_d_wf_runoff2_lyr[7], pihm_d->elem_d_wf_runoff2_lyr[8], pihm_d->elem_d_wf_runoff2_lyr[9], elem_d_wf_runoff2_lyr[10]};
realtype	*elem_d_ws_sh2o[]={pihm_d->elem_d_ws_sh2o[0], pihm_d->elem_d_ws_sh2o[1], pihm_d->elem_d_ws_sh2o[2],
	pihm_d->elem_d_ws_sh2o[3], pihm_d->elem_d_ws_sh2o[4], pihm_d->elem_d_ws_sh2o[5], pihm_d->elem_d_ws_sh2o[6],
	pihm_d->elem_d_ws_sh2o[7], pihm_d->elem_d_ws_sh2o[8], pihm_d->elem_d_ws_sh2o[9], pihm_d->elem_d_ws_sh2o[10]};	
realtype	*elem_d_ws_smc[]={pihm_d->elem_d_ws_smc[0], pihm_d->elem_d_ws_smc[1], pihm_d->elem_d_ws_smc[2],
	pihm_d->elem_d_ws_smc[3], pihm_d->elem_d_ws_smc[4], pihm_d->elem_d_ws_smc[5], pihm_d->elem_d_ws_smc[6],
	pihm_d->elem_d_ws_smc[7], pihm_d->elem_d_ws_smc[8], pihm_d->elem_d_ws_smc[9], pihm_d->elem_d_ws_smc[10]};
realtype *elem_d_ps_satdpth[] = {pihm_d->elem_d_ps_satdpth[0],pihm_d->elem_d_ps_satdpth[1],pihm_d->elem_d_ps_satdpth[2],
	pihm_d->elem_d_ps_satdpth[3],pihm_d->elem_d_ps_satdpth[4],pihm_d->elem_d_ps_satdpth[5],pihm_d->elem_d_ps_satdpth[6],
	pihm_d->elem_d_ps_satdpth[7],pihm_d->elem_d_ps_satdpth[8],pihm_d->elem_d_ps_satdpth[9],pihm_d->elem_d_ps_satdpth[10]};
realtype *elem_d_ps_sldpth[] = {pihm_d->elem_d_ps_sldpth[0],pihm_d->elem_d_ps_sldpth[1],pihm_d->elem_d_ps_sldpth[2],
	pihm_d->elem_d_ps_sldpth[3],pihm_d->elem_d_ps_sldpth[4],pihm_d->elem_d_ps_sldpth[5],pihm_d->elem_d_ps_sldpth[6],
	pihm_d->elem_d_ps_sldpth[7],pihm_d->elem_d_ps_sldpth[8],pihm_d->elem_d_ps_sldpth[9],pihm_d->elem_d_ps_sldpth[10]};
realtype	*elem_d_ps_zsoil[]={pihm_d->elem_d_ps_zsoil[0], pihm_d->elem_d_ps_zsoil[1], pihm_d->elem_d_ps_zsoil[2],
	pihm_d->elem_d_ps_zsoil[3], pihm_d->elem_d_ps_zsoil[4], pihm_d->elem_d_ps_zsoil[5], pihm_d->elem_d_ps_zsoil[6],
	pihm_d->elem_d_ps_zsoil[7], pihm_d->elem_d_ps_zsoil[8], pihm_d->elem_d_ps_zsoil[9], pihm_d->elem_d_ps_zsoil[10]};