int      *elem_d_lc_isurban,
int      *elem_d_ps_nsoil,
int      *elem_d_ps_nroot,
realtype *elem_d_lc_cfactr,
realtype *elem_d_lc_shdfac,
realtype *elem_d_ef_fdown,
realtype *elem_d_ef_flx1,
realtype *elem_d_ef_flx3,
realtype *elem_d_ef_ssoil,
realtype *elem_d_es_sfctmp,
realtype *elem_d_es_th2,
realtype *elem_d_es_t1,
realtype *elem_d_ps_beta,
realtype *elem_d_ps_emissi,
realtype *elem_d_ps_epsca,
realtype *elem_d_ps_fxexp,
realtype *elem_d_ps_pc,
realtype *elem_d_ps_rch,
realtype *elem_d_ps_rr,
realtype *elem_d_ps_sbeta,
realtype *elem_d_ps_tbot,
realtype *elem_d_ps_zbot,
realtype *elem_d_soil_alpha,
realtype *elem_d_soil_beta,
realtype *elem_d_soil_csoil,
realtype *elem_d_soil_quartz,
realtype *elem_d_soil_smcmin,
realtype *elem_d_soil_smcmax,
realtype *elem_d_soil_smcdry,
realtype *elem_d_soil_smcref,
realtype *elem_d_soil_smcwlt,
realtype *elem_d_wf_dew,
realtype *elem_d_wf_drip,
realtype *elem_d_wf_edir,
realtype *elem_d_wf_ec,
realtype *elem_d_wf_eta,
realtype *elem_d_wf_etns,
realtype *elem_d_wf_ett,
realtype *elem_d_wf_etp,
realtype *elem_d_wf_prcp,
realtype *elem_d_wf_pcpdrp,
realtype *elem_d_ws_cmc,
realtype *elem_d_ws_cmcmax,
realtype *elem_d_ws_smc[MAXLYR],
realtype *elem_d_ws_sh2o[MAXLYR],
realtype *elem_d_es_stc[MAXLYR],
realtype *elem_d_wf_et[MAXLYR],
realtype *elem_d_ps_rtdis[MAXLYR],
realtype *elem_d_ps_zsoil[MAXLYR]



















