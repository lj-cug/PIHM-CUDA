realtype *elem_d_topo_zmin,
realtype *elem_d_ws_gw,
realtype *elem_d_topo_nabrdist2,
realtype *elem_d_topo_edge2,
realtype *elem_d_bc_head2,
realtype *elem_d_bc_flux2,
realtype *elem_d_wf_ovlflow2,
realtype *elem_d_wf_subsurf2,
// EffKh arguments
realtype *elem_d_soil_areafv,
realtype *elem_d_soil_depth,
realtype *elem_d_soil_dmac,
realtype *elem_d_soil_kmach,
realtype *elem_d_soil_ksath