realtype *elem_d_ps_alb,
realtype *elem_d_ps_albedo,
realtype *elem_d_ps_embrd,
realtype *elem_d_ps_emissi,
realtype *elem_d_ps_lvcoef,
realtype *elem_d_ps_snoalb,
realtype *elem_d_ps_sncovr,
realtype *elem_d_ps_snotime1
