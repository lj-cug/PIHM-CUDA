realtype *elem_d_ws_gw,
realtype *elem_d_topo_zmin,
realtype *elem_d_topo_nabrdist1,
realtype *elem_d_topo_edge1,
// EffKh arguments
realtype *elem_d_soil_areafv,
realtype *elem_d_soil_depth,
realtype *elem_d_soil_dmac,
realtype *elem_d_soil_kmach,
realtype *elem_d_soil_ksath