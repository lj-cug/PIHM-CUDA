realtype *elem_d_soil_alpha,
realtype *elem_d_soil_beta,
realtype *elem_d_soil_ksatv,
realtype *elem_d_soil_smcmin,
realtype *elem_d_soil_smcmax



