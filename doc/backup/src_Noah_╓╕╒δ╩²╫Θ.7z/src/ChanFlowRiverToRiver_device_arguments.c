river_d_ws_stage,
river_d_topo_zbed,
river_d_matl_rough,
river_d_shp_coeff,
river_d_shp_length,
river_d_shp_intrpl_ord