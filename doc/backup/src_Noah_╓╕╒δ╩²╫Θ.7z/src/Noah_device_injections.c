int	        *elem_d_lc_isurban	=pihm_d->elem_d_lc_isurban;
int	        *elem_d_ps_nsoil	=pihm_d->elem_d_ps_nsoil; 
int	        *elem_d_ps_nroot	=pihm_d->elem_d_ps_nroot; 
realtype	*elem_d_ef_ec	    =pihm_d->elem_d_ef_ec;
realtype	*elem_d_ef_ett		=pihm_d->elem_d_ef_ett;
realtype	*elem_d_ef_edir		=pihm_d->elem_d_ef_edir;
realtype	*elem_d_ef_ssoil	=pihm_d->elem_d_ef_ssoil;
realtype	*elem_d_ef_esnow	=pihm_d->elem_d_ef_esnow;
realtype	*elem_d_ef_eta		=pihm_d->elem_d_ef_eta;
realtype	*elem_d_ef_etp		=pihm_d->elem_d_ef_etp;
realtype	*elem_d_ef_fdown	=pihm_d->elem_d_ef_fdown;
realtype	*elem_d_ef_flx1		=pihm_d->elem_d_ef_flx1;
realtype	*elem_d_ef_flx2		=pihm_d->elem_d_ef_flx2;
realtype	*elem_d_ef_flx3		=pihm_d->elem_d_ef_flx3;
realtype	*elem_d_ef_sheat	=pihm_d->elem_d_ef_sheat;
realtype	*elem_d_ef_longwave	=pihm_d->elem_d_ef_longwave;
realtype	*elem_d_ef_lwdn		=pihm_d->elem_d_ef_lwdn;
realtype	*elem_d_ef_soldn	=pihm_d->elem_d_ef_soldn;
realtype	*elem_d_ef_solnet	=pihm_d->elem_d_ef_solnet;
realtype	*elem_d_es_sfctmp	=pihm_d->elem_d_es_sfctmp;
realtype	*elem_d_es_t1		=pihm_d->elem_d_es_t1;
realtype	*elem_d_es_th2		=pihm_d->elem_d_es_th2;
realtype	*elem_d_epc_hs		=pihm_d->elem_d_epc_hs;
realtype	*elem_d_epc_rgl		=pihm_d->elem_d_epc_rgl;
realtype	*elem_d_epc_topt	=pihm_d->elem_d_epc_topt;
realtype	*elem_d_epc_rsmin	=pihm_d->elem_d_epc_rsmin;
realtype	*elem_d_epc_rsmax	=pihm_d->elem_d_epc_rsmax;
realtype	*elem_d_lc_albedomin=pihm_d->elem_d_lc_albedomin;
realtype	*elem_d_lc_albedomax=pihm_d->elem_d_lc_albedomax;
realtype	*elem_d_lc_cmcfactr	=pihm_d->elem_d_lc_cmcfactr;
realtype	*elem_d_lc_emissmin	=pihm_d->elem_d_lc_emissmin;
realtype	*elem_d_lc_emissmax	=pihm_d->elem_d_lc_emissmax;
realtype	*elem_d_lc_laimin	=pihm_d->elem_d_lc_laimin;
realtype	*elem_d_lc_laimax	=pihm_d->elem_d_lc_laimax;
realtype	*elem_d_lc_cfactr	=pihm_d->elem_d_lc_cfactr;
realtype	*elem_d_lc_shdfac	=pihm_d->elem_d_lc_shdfac;
realtype	*elem_d_lc_snup		=pihm_d->elem_d_lc_snup;
realtype	*elem_d_lc_z0min	=pihm_d->elem_d_lc_z0min;
realtype	*elem_d_lc_z0max	=pihm_d->elem_d_lc_z0max;
realtype	*elem_d_ps_alb		=pihm_d->elem_d_ps_alb;
realtype	*elem_d_ps_albedo	=pihm_d->elem_d_ps_albedo;
realtype	*elem_d_ps_beta		=pihm_d->elem_d_ps_beta;
realtype	*elem_d_ps_ch		=pihm_d->elem_d_ps_ch;
realtype	*elem_d_ps_cm		=pihm_d->elem_d_ps_cm;
realtype	*elem_d_ps_czil		=pihm_d->elem_d_ps_czil;
realtype	*elem_d_ps_dqsdt2	=pihm_d->elem_d_ps_dqsdt2;
realtype	*elem_d_ps_embrd	=pihm_d->elem_d_ps_embrd;
realtype	*elem_d_ps_emissi	=pihm_d->elem_d_ps_emissi;
realtype	*elem_d_ps_epsca	=pihm_d->elem_d_ps_epsca;
realtype	*elem_d_ps_eta_kinematic=pihm_d->elem_d_ps_eta_kinematic;
realtype	*elem_d_ps_ffrozp	=pihm_d->elem_d_ps_ffrozp;
realtype    *elem_d_ps_fxexp    =pihm_d->elem_d_ps_fxexp;
realtype	*elem_d_ps_lvcoef	=pihm_d->elem_d_ps_lvcoef;
realtype	*elem_d_ps_proj_lai	=pihm_d->elem_d_ps_proj_lai;
realtype	*elem_d_ps_pc		=pihm_d->elem_d_ps_pc;
realtype	*elem_d_ps_q1		=pihm_d->elem_d_ps_q1;
realtype	*elem_d_ps_q2		=pihm_d->elem_d_ps_q2;
realtype	*elem_d_ps_q2sat	=pihm_d->elem_d_ps_q2sat;
realtype	*elem_d_ps_rc		=pihm_d->elem_d_ps_rc;
realtype	*elem_d_ps_rh		=pihm_d->elem_d_ps_rh;
realtype    *elem_d_ps_ribb     =pihm_d->elem_d_ps_ribb;
realtype	*elem_d_ps_rch		=pihm_d->elem_d_ps_rch;
realtype	*elem_d_ps_rr		=pihm_d->elem_d_ps_rr;
realtype	*elem_d_ps_rcs		=pihm_d->elem_d_ps_rcs;
realtype	*elem_d_ps_rct		=pihm_d->elem_d_ps_rct;
realtype	*elem_d_ps_rcq		=pihm_d->elem_d_ps_rcq;
realtype	*elem_d_ps_rcsoil	=pihm_d->elem_d_ps_rcsoil;
realtype	*elem_d_ps_sfcprs	=pihm_d->elem_d_ps_sfcprs;
realtype	*elem_d_ps_salp		=pihm_d->elem_d_ps_salp;
realtype	*elem_d_ps_sbeta	=pihm_d->elem_d_ps_sbeta;
realtype	*elem_d_ps_sfcspd	=pihm_d->elem_d_ps_sfcspd;
realtype	*elem_d_ps_sndens	=pihm_d->elem_d_ps_sndens;
realtype	*elem_d_ps_snowh	=pihm_d->elem_d_ps_snowh;
realtype	*elem_d_ps_sncond	=pihm_d->elem_d_ps_sncond;
realtype	*elem_d_ps_sncovr	=pihm_d->elem_d_ps_sncovr;
realtype	*elem_d_ps_snoalb	=pihm_d->elem_d_ps_snoalb;
realtype	*elem_d_ps_snotime1	=pihm_d->elem_d_ps_snotime1;
realtype	*elem_d_ps_soilw	=pihm_d->elem_d_ps_soilw;
realtype	*elem_d_ps_tbot		=pihm_d->elem_d_ps_tbot;
realtype	*elem_d_ps_z0		=pihm_d->elem_d_ps_z0;
realtype	*elem_d_ps_z0brd	=pihm_d->elem_d_ps_z0brd;
realtype	*elem_d_ps_zbot		=pihm_d->elem_d_ps_zbot;
realtype	*elem_d_ps_zlvl		=pihm_d->elem_d_ps_zlvl;
realtype	*elem_d_ps_zlvl_wind=pihm_d->elem_d_ps_zlvl_wind;
realtype	*elem_d_soil_alpha	=pihm_d->elem_d_soil_alpha;
realtype	*elem_d_soil_beta	=pihm_d->elem_d_soil_beta;
realtype	*elem_d_soil_csoil	=pihm_d->elem_d_soil_csoil;
realtype	*elem_d_soil_quartz	=pihm_d->elem_d_soil_quartz;
realtype	*elem_d_soil_smcmin	=pihm_d->elem_d_soil_smcmin;
realtype	*elem_d_soil_smcmax	=pihm_d->elem_d_soil_smcmax;
realtype	*elem_d_soil_smcref	=pihm_d->elem_d_soil_smcref;
realtype	*elem_d_soil_smcwlt	=pihm_d->elem_d_soil_smcwlt;
realtype	*elem_d_soil_smcdry	=pihm_d->elem_d_soil_smcdry;
realtype	*elem_d_wf_dew		=pihm_d->elem_d_wf_dew;
realtype	*elem_d_wf_drip		=pihm_d->elem_d_wf_drip;
realtype	*elem_d_wf_ec		=pihm_d->elem_d_wf_ec;
realtype	*elem_d_wf_eta		=pihm_d->elem_d_wf_eta;
realtype	*elem_d_wf_etns		=pihm_d->elem_d_wf_etns;
realtype	*elem_d_wf_etp		=pihm_d->elem_d_wf_etp;
realtype	*elem_d_wf_ett		=pihm_d->elem_d_wf_ett;
realtype	*elem_d_wf_edir		=pihm_d->elem_d_wf_edir;
realtype	*elem_d_wf_esnow	=pihm_d->elem_d_wf_esnow;
realtype	*elem_d_wf_prcp		=pihm_d->elem_d_wf_prcp;
realtype	*elem_d_wf_pcpdrp	=pihm_d->elem_d_wf_pcpdrp;
realtype	*elem_d_wf_snomlt	=pihm_d->elem_d_wf_snomlt;
realtype	*elem_d_ws_cmc		=pihm_d->elem_d_ws_cmc;
realtype	*elem_d_ws_cmcmax	=pihm_d->elem_d_ws_cmcmax;
realtype	*elem_d_ws_soilm	=pihm_d->elem_d_ws_soilm;
realtype	*elem_d_ws_sneqv	=pihm_d->elem_d_ws_sneqv; 

// MAXLYR = 11 
realtype	*elem_d_ef_et[] = {pihm_d->elem_d_ef_et[0], pihm_d->elem_d_ef_et[1], pihm_d->elem_d_ef_et[2],
	pihm_d->elem_d_ef_et[3], pihm_d->elem_d_ef_et[4], pihm_d->elem_d_ef_et[5], pihm_d->elem_d_ef_et[6],
	pihm_d->elem_d_ef_et[7], pihm_d->elem_d_ef_et[8], pihm_d->elem_d_ef_et[9], pihm_d->elem_d_ef_et[10]};
realtype	*elem_d_es_stc[]={pihm_d->elem_d_es_stc[0], pihm_d->elem_d_es_stc[1], pihm_d->elem_d_es_stc[2],
	pihm_d->elem_d_es_stc[3], pihm_d->elem_d_es_stc[4], pihm_d->elem_d_es_stc[5], pihm_d->elem_d_es_stc[6],
	pihm_d->elem_d_es_stc[7], pihm_d->elem_d_es_stc[8], pihm_d->elem_d_es_stc[9], pihm_d->elem_d_es_stc[10]};
realtype    *elem_d_ps_rtdis[]={pihm_d->elem_d_ps_rtdis[0], pihm_d->elem_d_ps_rtdis[1], pihm_d->elem_d_ps_rtdis[2],
	pihm_d->elem_d_ps_rtdis[3], pihm_d->elem_d_ps_rtdis[4], pihm_d->elem_d_ps_rtdis[5], pihm_d->elem_d_ps_rtdis[6],
	pihm_d->elem_d_ps_rtdis[7], pihm_d->elem_d_ps_rtdis[8], pihm_d->elem_d_ps_rtdis[9], pihm_d->elem_d_ps_rtdis[10]};
realtype	*elem_d_ps_zsoil[]={pihm_d->elem_d_ps_zsoil[0], pihm_d->elem_d_ps_zsoil[1], pihm_d->elem_d_ps_zsoil[2],
	pihm_d->elem_d_ps_zsoil[3], pihm_d->elem_d_ps_zsoil[4], pihm_d->elem_d_ps_zsoil[5], pihm_d->elem_d_ps_zsoil[6],
	pihm_d->elem_d_ps_zsoil[7], pihm_d->elem_d_ps_zsoil[8], pihm_d->elem_d_ps_zsoil[9], pihm_d->elem_d_ps_zsoil[10]};
realtype	*elem_d_wf_et[]={pihm_d->elem_d_wf_et[0], pihm_d->elem_d_wf_et[1], pihm_d->elem_d_wf_et[2],
	pihm_d->elem_d_wf_et[3], pihm_d->elem_d_wf_et[4], pihm_d->elem_d_wf_et[5], pihm_d->elem_d_wf_et[6],
	pihm_d->elem_d_wf_et[7], pihm_d->elem_d_wf_et[8], pihm_d->elem_d_wf_et[9], pihm_d->elem_d_wf_et[10]};
realtype	*elem_d_ws_smc[]={pihm_d->elem_d_ws_smc[0], pihm_d->elem_d_ws_smc[1], pihm_d->elem_d_ws_smc[2],
	pihm_d->elem_d_ws_smc[3], pihm_d->elem_d_ws_smc[4], pihm_d->elem_d_ws_smc[5], pihm_d->elem_d_ws_smc[6],
	pihm_d->elem_d_ws_smc[7], pihm_d->elem_d_ws_smc[8], pihm_d->elem_d_ws_smc[9], pihm_d->elem_d_ws_smc[10]};
realtype	*elem_d_ws_sh2o[]={pihm_d->elem_d_ws_sh2o[0], pihm_d->elem_d_ws_sh2o[1], pihm_d->elem_d_ws_sh2o[2],
	pihm_d->elem_d_ws_sh2o[3], pihm_d->elem_d_ws_sh2o[4], pihm_d->elem_d_ws_sh2o[5], pihm_d->elem_d_ws_sh2o[6],
	pihm_d->elem_d_ws_sh2o[7], pihm_d->elem_d_ws_sh2o[8], pihm_d->elem_d_ws_sh2o[9], pihm_d->elem_d_ws_sh2o[10]};	