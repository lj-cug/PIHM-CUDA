realtype *elem_d_topo_zmax,
realtype *elem_d_ws_surfh,
realtype *river_d_topo_zmax,
realtype *river_d_topo_zbed,
realtype *river_d_matl_cwr,
realtype *river_d_shp_length,
realtype *river_d_ws_stage



