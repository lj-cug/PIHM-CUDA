realtype *river_d_shp_width,
realtype *river_d_shp_length,
realtype *river_d_topo_zmin,
realtype *river_d_ws_gw