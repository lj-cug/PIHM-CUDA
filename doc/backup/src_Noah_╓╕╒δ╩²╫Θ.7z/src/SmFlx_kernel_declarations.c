int      *elem_d_ps_nsoil,
realtype *elem_d_ps_fcr,
realtype *elem_d_ps_frzx,
int      *elem_d_ps_nwtbl,
realtype *elem_d_soil_alpha,
realtype *elem_d_soil_beta,
realtype *elem_d_soil_ksatv,
realtype *elem_d_soil_smcmin,
realtype *elem_d_soil_smcmax,
realtype *elem_d_wf_infil,
realtype *elem_d_wf_edir,
realtype *elem_d_wf_runoff3,
realtype *elem_d_wf_et[MAXLYR],
realtype *elem_d_wf_smflxv[MAXLYR],
realtype *elem_d_wf_runoff2_lyr[MAXLYR],
realtype *elem_d_ws_sh2o[MAXLYR],
realtype *elem_d_ws_smc[MAXLYR],
realtype *elem_d_ps_satdpth[MAXLYR],
realtype *elem_d_ps_sldpth[MAXLYR],
realtype *elem_d_ps_zsoil[MAXLYR]




