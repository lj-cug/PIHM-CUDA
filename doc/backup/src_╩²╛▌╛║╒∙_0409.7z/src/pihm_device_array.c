/* elem_d related arguments */
    int *elem_d_attrib_soil_type; 
	int *elem_d_attrib_lc_type;             
    int *elem_d_attrib_bc_type[NUM_EDGE];
	int *elem_d_attrib_meteo_type; 
	int *elem_d_attrib_lai_type;   /* Element attribute */          
    double *elem_d_topo_area; 
	double *elem_d_topo_x; 
	double *elem_d_topo_y;                               
    double *elem_d_topo_zmin; 
	double *elem_d_topo_zmax;                                
	double *elem_d_topo_edge[NUM_EDGE]; 
	double *elem_d_topo_nabrdist[NUM_EDGE];        
    double *elem_d_topo_nabr_x[NUM_EDGE]; 
	double *elem_d_topo_nabr_y[NUM_EDGE]; /* Topography */                 
    double *elem_d_soil_depth;
	double *elem_d_soil_ksath; 
	double *elem_d_soil_ksatv;     
    double *elem_d_soil_kinfv; 
	double *elem_d_soil_dinf; 
	double *elem_d_soil_alpha;     
    double *elem_d_soil_beta; 
	double *elem_d_soil_porosity; 
	double *elem_d_soil_smcmax;        
    double *elem_d_soil_smcmin;
	double *elem_d_soil_smcwlt; 
	double *elem_d_soil_smcref;    
    double *elem_d_soil_dmac; 
	double *elem_d_soil_kmach; 
	double *elem_d_soil_kmacv;  
    double *elem_d_soil_areafv; 
	double *elem_d_soil_areafh;  /* Soil parameters */
    double *elem_d_lc_shdfac; 
	double *elem_d_lc_shdmin; 
	double *elem_d_lc_shdmax;     
    double *elem_d_lc_laimin; 
	double *elem_d_lc_laimax; 
	double *elem_d_lc_snup;         
    double *elem_d_lc_cfactr; 
	double *elem_d_lc_emissmax; 
	double *elem_d_lc_emissmin;     
    double *elem_d_lc_albedomax; 
	double *elem_d_lc_albedomin; 
	double *elem_d_lc_z0max;  
    double *elem_d_lc_z0min; 
	double *elem_d_lc_rough; 
	double *elem_d_lc_cmcfactr;       
    int *elem_d_lc_bare; 
	int *elem_d_lc_isurban;   /* Land cover parameters */ 
    double *elem_d_epc_rsmin; 
	double *elem_d_epc_rgl; 
	double *elem_d_epc_hs;       
    double *elem_d_epc_topt; 
	double *elem_d_epc_rsmax;  /* Ecophysiological parameters */    
    double *elem_d_ps_rzd; 
	double *elem_d_ps_rc; 
	double *elem_d_ps_pc;                
    double *elem_d_ps_proj_lai; 
	double *elem_d_ps_rcs; 
	double *elem_d_ps_rct;        
    double *elem_d_ps_rcq; 
	double *elem_d_ps_rcsoil; 
	double *elem_d_ps_albedo;          
    double *elem_d_ps_zlvl; 
	double *elem_d_ps_zlvl_wind; 
	double *elem_d_ps_sfcspd;         
    double *elem_d_ps_rh; 
	double *elem_d_ps_sfcprs;  /* Physical states */    
    double *elem_d_ws_surf; 
	double *elem_d_ws_unsat; 
	double *elem_d_ws_gw; 
	double *elem_d_ws_sneqv;                  
    double *elem_d_ws_cmcmax;  
	double *elem_d_ws_cmc;  
	double *elem_d_ws_surfh;  /* Water states */
	double *elem_d_ws0_surf; 
	double *elem_d_ws0_unsat; 
	double *elem_d_ws0_gw;  
	double *elem_d_ws0_sneqv; 
	double *elem_d_ws0_cmcmax;
    double *elem_d_ws0_cmc; 
	double *elem_d_ws0_surfh;   /* Initial Water states */	     
    double *elem_d_wf_ovlflow[NUM_EDGE]; 
	double *elem_d_wf_subsurf[NUM_EDGE];   
    double *elem_d_wf_prcp; 
	double *elem_d_wf_pcpdrp; 
	double *elem_d_wf_infil;                        
    double *elem_d_wf_rechg; 
	double *elem_d_wf_drip; 
	double *elem_d_wf_edir;                       
    double *elem_d_wf_ett; 
	double *elem_d_wf_ec; 
	double *elem_d_wf_etp;                           
    double *elem_d_wf_eta; 
	double *elem_d_wf_edir_surf; 
	double *elem_d_wf_edir_unsat;                      
    double *elem_d_wf_edir_gw; 
	double *elem_d_wf_ett_unsat; 
	double *elem_d_wf_ett_gw;                     
    double *elem_d_wf_esnow;          /* Water fluxes */         
    double *elem_d_es_sfctmp;         /* Energy states */
    double *elem_d_ef_soldn;          /* Energy fluxes */ 
    double *elem_d_bc_head[NUM_EDGE]; 
	double *elem_d_bc_flux[NUM_EDGE]; /* Boundary conditions */
    int *elem_d_node[NUM_EDGE]; 
	int *elem_d_nabr[NUM_EDGE]; 
	int *elem_d_ind;     /* Elements' geometric numbers */  	
/* river_d related arguments */           
    int *river_d_attrib_riverbc_type;    /* River attribute */
    double *river_d_topo_area; 
	double *river_d_topo_x; 
	double *river_d_topo_y;                 
    double *river_d_topo_zmin;
	double *river_d_topo_zmax; 
	double *river_d_topo_zbed;                            
    double *river_d_topo_node_zmax; 
	double *river_d_topo_dist_left; 
	double *river_d_topo_dist_right;    /* River topography */   
    double *river_d_ws_stage; 
	double *river_d_ws_gw;              /* River water states */
    double *river_d_wf_rivflow[NUM_RIVFLX];  /* River water fluxes */   
    double *river_d_shp_depth; 
	int    *river_d_shp_intrpl_ord;  
	double *river_d_shp_coeff;     
    double *river_d_shp_length; 
	double *river_d_shp_width;       /* River shape parameters */     
    double *river_d_matl_rough; 
	double *river_d_matl_cwr; 
	double *river_d_matl_ksath;         
    double *river_d_matl_ksatv; 
	double *river_d_matl_bedthick; 
	double *river_d_matl_porosity;     
    double *river_d_matl_smcmin;   /* River mathmatic parameters */	
    double *river_d_bc_head; 
	double *river_d_bc_flux;       /* River boundary conditions */  
    int *river_d_ind; 
	int *river_d_leftele; 
	int *river_d_rightele;      
    int *river_d_fromnode; 
	int *river_d_tonode; 
	int *river_d_down;        /* River geometric numbers */