/* elem_d related arguments */			
int *elem_d_attrib_soil_type 	        =pihm_d->elem_d_attrib_soil_type; 
int *elem_d_attrib_lc_type             	=pihm_d->elem_d_attrib_lc_type;

/* ����CVode_CUDA���õ�Ҫ�󣬽�ָ�������ַ�ֱ𸳸�һά���飬�ٴ���˺��� */
int *elem_d_attrib_bc_type0   =   pihm_d->elem_d_attrib_bc_type[0]; 
int *elem_d_attrib_bc_type1   =   pihm_d->elem_d_attrib_bc_type[1];
int *elem_d_attrib_bc_type2   =   pihm_d->elem_d_attrib_bc_type[2];	
			 
int *elem_d_attrib_meteo_type 	        =pihm_d->elem_d_attrib_meteo_type;
int *elem_d_attrib_lai_type        	    =pihm_d->elem_d_attrib_lai_type;         
double *elem_d_topo_area 	            =pihm_d->elem_d_topo_area; 
double *elem_d_topo_x 	                =pihm_d->elem_d_topo_x; 
double *elem_d_topo_y                   =pihm_d->elem_d_topo_y;
double *elem_d_topo_zmin 	            =pihm_d->elem_d_topo_zmin; 
double *elem_d_topo_zmax                =pihm_d->elem_d_topo_zmax;

double *elem_d_topo_edge0  = 	pihm_d->elem_d_topo_edge[0];
double *elem_d_topo_edge1  = 	pihm_d->elem_d_topo_edge[1];	  
double *elem_d_topo_edge2  = 	pihm_d->elem_d_topo_edge[2];			  
			  
double *elem_d_topo_nabrdist0  =   pihm_d->elem_d_topo_nabrdist[0];		  
double *elem_d_topo_nabrdist1  =   pihm_d->elem_d_topo_nabrdist[1];		  			  
double *elem_d_topo_nabrdist2  =   pihm_d->elem_d_topo_nabrdist[2];		  			  
			  
double *elem_d_topo_nabr_x0  = 	   pihm_d->elem_d_topo_nabr_x[0];  
double *elem_d_topo_nabr_x1  = 	   pihm_d->elem_d_topo_nabr_x[1];  
double *elem_d_topo_nabr_x2  = 	   pihm_d->elem_d_topo_nabr_x[2];  		  
		  
double *elem_d_topo_nabr_y0  =    pihm_d->elem_d_topo_nabr_y[0];  
double *elem_d_topo_nabr_y1  =    pihm_d->elem_d_topo_nabr_y[1];  		  
double *elem_d_topo_nabr_y2  =    pihm_d->elem_d_topo_nabr_y[2];  	
						
double *elem_d_soil_depth	            =pihm_d->elem_d_soil_depth; 
double *elem_d_soil_ksath 	            =pihm_d->elem_d_soil_ksath; 
double *elem_d_soil_ksatv     	        =pihm_d->elem_d_soil_ksatv;
double *elem_d_soil_kinfv 				=pihm_d->elem_d_soil_kinfv; 
double *elem_d_soil_dinf 				=pihm_d->elem_d_soil_dinf; 
double *elem_d_soil_alpha     			=pihm_d->elem_d_soil_alpha;
double *elem_d_soil_beta 				=pihm_d->elem_d_soil_beta; 
double *elem_d_soil_porosity 			=pihm_d->elem_d_soil_porosity; 
double *elem_d_soil_smcmax        		=pihm_d->elem_d_soil_smcmax;
double *elem_d_soil_smcmin				=pihm_d->elem_d_soil_smcmin; 
double *elem_d_soil_smcwlt 				=pihm_d->elem_d_soil_smcwlt; 
double *elem_d_soil_smcref    			=pihm_d->elem_d_soil_smcref;
double *elem_d_soil_dmac 				=pihm_d->elem_d_soil_dmac; 
double *elem_d_soil_kmach 				=pihm_d->elem_d_soil_kmach; 
double *elem_d_soil_kmacv  				=pihm_d->elem_d_soil_kmacv;
double *elem_d_soil_areafv 				=pihm_d->elem_d_soil_areafv; 
double *elem_d_soil_areafh    			=pihm_d->elem_d_soil_areafh;             
double *elem_d_lc_shdfac 				=pihm_d->elem_d_lc_shdfac; 
double *elem_d_lc_shdmin 				=pihm_d->elem_d_lc_shdmin; 
double *elem_d_lc_shdmax     			=pihm_d->elem_d_lc_shdmax;
double *elem_d_lc_laimin 				=pihm_d->elem_d_lc_laimin; 
double *elem_d_lc_laimax 				=pihm_d->elem_d_lc_laimax; 
double *elem_d_lc_snup         			=pihm_d->elem_d_lc_snup;
double *elem_d_lc_cfactr 				=pihm_d->elem_d_lc_cfactr; 
double *elem_d_lc_emissmax 				=pihm_d->elem_d_lc_emissmax; 
double *elem_d_lc_emissmin     			=pihm_d->elem_d_lc_emissmin;
double *elem_d_lc_albedomax 			=pihm_d->elem_d_lc_albedomax; 
double *elem_d_lc_albedomin 			=pihm_d->elem_d_lc_albedomin; 
double *elem_d_lc_z0max  				=pihm_d->elem_d_lc_z0max;
double *elem_d_lc_z0min 				=pihm_d->elem_d_lc_z0min; 
double *elem_d_lc_rough 				=pihm_d->elem_d_lc_rough; 
double *elem_d_lc_cmcfactr       		=pihm_d->elem_d_lc_cmcfactr;
int *elem_d_lc_bare 					=pihm_d->elem_d_lc_bare; 
int *elem_d_lc_isurban   				=pihm_d->elem_d_lc_isurban;    
double *elem_d_epc_rsmin 				=pihm_d->elem_d_epc_rsmin; 
double *elem_d_epc_rgl 					=pihm_d->elem_d_epc_rgl; 
double *elem_d_epc_hs       			=pihm_d->elem_d_epc_hs;
double *elem_d_epc_topt 				=pihm_d->elem_d_epc_topt;
double *elem_d_epc_rsmax  				=pihm_d->elem_d_epc_rsmax;     
double *elem_d_ps_rzd 					=pihm_d->elem_d_ps_rzd; 
double *elem_d_ps_rc 					=pihm_d->elem_d_ps_rc; 
double *elem_d_ps_pc                	=pihm_d->elem_d_ps_pc;
double *elem_d_ps_proj_lai 				=pihm_d->elem_d_ps_proj_lai; 
double *elem_d_ps_rcs 					=pihm_d->elem_d_ps_rcs; 
double *elem_d_ps_rct        			=pihm_d->elem_d_ps_rct;
double *elem_d_ps_rcq 					=pihm_d->elem_d_ps_rcq; 
double *elem_d_ps_rcsoil 				=pihm_d->elem_d_ps_rcsoil; 
double *elem_d_ps_albedo          		=pihm_d->elem_d_ps_albedo;
double *elem_d_ps_zlvl 					=pihm_d->elem_d_ps_zlvl; 
double *elem_d_ps_zlvl_wind 			=pihm_d->elem_d_ps_zlvl_wind; 
double *elem_d_ps_sfcspd         		=pihm_d->elem_d_ps_sfcspd;
double *elem_d_ps_rh 					=pihm_d->elem_d_ps_rh; 
double *elem_d_ps_sfcprs      			=pihm_d->elem_d_ps_sfcprs;       
double *elem_d_ws_surf 					=pihm_d->elem_d_ws_surf; 
double *elem_d_ws_unsat 				=pihm_d->elem_d_ws_unsat; 
double *elem_d_ws_gw 					=pihm_d->elem_d_ws_gw; 
double *elem_d_ws_sneqv                 =pihm_d->elem_d_ws_sneqv;
double *elem_d_ws_cmcmax  				=pihm_d->elem_d_ws_cmcmax; 
double *elem_d_ws_cmc  					=pihm_d->elem_d_ws_cmc; 
double *elem_d_ws_surfh 				=pihm_d->elem_d_ws_surfh;      
double *elem_d_ws0_surf 				=pihm_d->elem_d_ws0_surf; 
double *elem_d_ws0_unsat 				=pihm_d->elem_d_ws0_unsat; 
double *elem_d_ws0_gw  					=pihm_d->elem_d_ws0_gw;
double *elem_d_ws0_sneqv 				=pihm_d->elem_d_ws0_sneqv; 
double *elem_d_ws0_cmcmax               =pihm_d->elem_d_ws0_cmcmax;
double *elem_d_ws0_cmc 					=pihm_d->elem_d_ws0_cmc; 
double *elem_d_ws0_surfh        		=pihm_d->elem_d_ws0_surfh;  

double *elem_d_wf_ovlflow0  =  pihm_d->elem_d_wf_ovlflow[0];
double *elem_d_wf_ovlflow1  =  pihm_d->elem_d_wf_ovlflow[1];
double *elem_d_wf_ovlflow2  =  pihm_d->elem_d_wf_ovlflow[2];

double *elem_d_wf_subsurf0  =  pihm_d->elem_d_wf_subsurf[0];
double *elem_d_wf_subsurf1  =  pihm_d->elem_d_wf_subsurf[1];
double *elem_d_wf_subsurf2  =  pihm_d->elem_d_wf_subsurf[2];			 
			 
double *elem_d_wf_prcp 					=pihm_d->elem_d_wf_prcp; 
double *elem_d_wf_pcpdrp 				=pihm_d->elem_d_wf_pcpdrp; 
double *elem_d_wf_infil                 =pihm_d->elem_d_wf_infil;
double *elem_d_wf_rechg 				=pihm_d->elem_d_wf_rechg; 
double *elem_d_wf_drip 					=pihm_d->elem_d_wf_drip; 
double *elem_d_wf_edir                  =pihm_d->elem_d_wf_edir;
double *elem_d_wf_ett 					=pihm_d->elem_d_wf_ett; 
double *elem_d_wf_ec 					=pihm_d->elem_d_wf_ec; 
double *elem_d_wf_etp                   =pihm_d->elem_d_wf_etp;
double *elem_d_wf_eta 					=pihm_d->elem_d_wf_eta; 
double *elem_d_wf_edir_surf 			=pihm_d->elem_d_wf_edir_surf; 
double *elem_d_wf_edir_unsat            =pihm_d->elem_d_wf_edir_unsat;
double *elem_d_wf_edir_gw 				=pihm_d->elem_d_wf_edir_gw; 
double *elem_d_wf_ett_unsat 			=pihm_d->elem_d_wf_ett_unsat; 
double *elem_d_wf_ett_gw                =pihm_d->elem_d_wf_ett_gw;
double *elem_d_wf_esnow               	=pihm_d->elem_d_wf_esnow;         
double *elem_d_es_sfctmp         	    =pihm_d->elem_d_es_sfctmp;         
double *elem_d_ef_soldn         	    =pihm_d->elem_d_ef_soldn;   

double *elem_d_bc_head0  =  pihm_d->elem_d_bc_head[0];
double *elem_d_bc_head1  =  pihm_d->elem_d_bc_head[1]; 
double *elem_d_bc_head2  =  pihm_d->elem_d_bc_head[2];

double *elem_d_bc_flux0  =  pihm_d->elem_d_bc_flux[0];
double *elem_d_bc_flux1  =  pihm_d->elem_d_bc_flux[1];
double *elem_d_bc_flux2  =  pihm_d->elem_d_bc_flux[2];  

int *elem_d_node0  =  pihm_d->elem_d_node[0];
int *elem_d_node1  =  pihm_d->elem_d_node[1];
int *elem_d_node2  =  pihm_d->elem_d_node[2];

int *elem_d_nabr0  =  pihm_d->elem_d_nabr[0];
int *elem_d_nabr1  =  pihm_d->elem_d_nabr[1];
int *elem_d_nabr2  =  pihm_d->elem_d_nabr[2];
		
int *elem_d_ind 						=pihm_d->elem_d_ind; 
  
/* river_d related arguments */          		
int *river_d_attrib_riverbc_type		=pihm_d->river_d_attrib_riverbc_type;   
double *river_d_topo_area 				=pihm_d->river_d_topo_area; 
double *river_d_topo_x 					=pihm_d->river_d_topo_x; 
double *river_d_topo_y                 	=pihm_d->river_d_topo_y;
double *river_d_topo_zmin				=pihm_d->river_d_topo_zmin; 
double *river_d_topo_zmax 				=pihm_d->river_d_topo_zmax; 
double *river_d_topo_zbed               =pihm_d->river_d_topo_zbed;
double *river_d_topo_node_zmax 			=pihm_d->river_d_topo_node_zmax; 
double *river_d_topo_dist_left 			=pihm_d->river_d_topo_dist_left;
double *river_d_topo_dist_right 		=pihm_d->river_d_topo_dist_right;        
double *river_d_ws_stage 				=pihm_d->river_d_ws_stage; 
double *river_d_ws_gw					=pihm_d->river_d_ws_gw; 

double *river_d_wf_rivflow0  =  pihm_d->river_d_wf_rivflow[0];
double *river_d_wf_rivflow1  =  pihm_d->river_d_wf_rivflow[1];
double *river_d_wf_rivflow2  =  pihm_d->river_d_wf_rivflow[2];
double *river_d_wf_rivflow3  =  pihm_d->river_d_wf_rivflow[3];
double *river_d_wf_rivflow4  =  pihm_d->river_d_wf_rivflow[4];
double *river_d_wf_rivflow5  =  pihm_d->river_d_wf_rivflow[5];
double *river_d_wf_rivflow6  =  pihm_d->river_d_wf_rivflow[6];
double *river_d_wf_rivflow7  =  pihm_d->river_d_wf_rivflow[7];
double *river_d_wf_rivflow8  =  pihm_d->river_d_wf_rivflow[8];
double *river_d_wf_rivflow9  =  pihm_d->river_d_wf_rivflow[9];
double *river_d_wf_rivflow10 =  pihm_d->river_d_wf_rivflow[10];
		
double *river_d_shp_depth 				=pihm_d->river_d_shp_depth; 
int    *river_d_shp_intrpl_ord  		=pihm_d->river_d_shp_intrpl_ord; 
double *river_d_shp_coeff     			=pihm_d->river_d_shp_coeff;
double *river_d_shp_length 				=pihm_d->river_d_shp_length; 
double *river_d_shp_width         		=pihm_d->river_d_shp_width;      
double *river_d_matl_rough 				=pihm_d->river_d_matl_rough; 
double *river_d_matl_cwr 				=pihm_d->river_d_matl_cwr; 
double *river_d_matl_ksath         		=pihm_d->river_d_matl_ksath;
double *river_d_matl_ksatv 				=pihm_d->river_d_matl_ksatv; 
double *river_d_matl_bedthick 			=pihm_d->river_d_matl_bedthick; 
double *river_d_matl_porosity     		=pihm_d->river_d_matl_porosity;
double *river_d_matl_smcmin 			=pihm_d->river_d_matl_smcmin;      
double *river_d_bc_head 	  			=pihm_d->river_d_bc_head; 
double *river_d_bc_flux  	  			=pihm_d->river_d_bc_flux;          
int *river_d_ind 			  			=pihm_d->river_d_ind; 
int *river_d_leftele 		  			=pihm_d->river_d_leftele; 
int *river_d_rightele      	  			=pihm_d->river_d_rightele;
int *river_d_fromnode 	      			=pihm_d->river_d_fromnode; 
int *river_d_tonode 	      			=pihm_d->river_d_tonode; 
int *river_d_down  		      			=pihm_d->river_d_down; 