/* elem_d related arguments */
    int *elem_d_attrib_soil_type, 
	int *elem_d_attrib_lc_type, 
	
	// �޸�Ϊ������׵�ַ�βδ���
    int *elem_d_attrib_bc_type0,
	int *elem_d_attrib_bc_type1,
	int *elem_d_attrib_bc_type2,
	
	int *elem_d_attrib_meteo_type, 
	int *elem_d_attrib_lai_type, /* Element attribute */          
    double *elem_d_topo_area, 
	double *elem_d_topo_x, 
	double *elem_d_topo_y,                               
    double *elem_d_topo_zmin, 
	double *elem_d_topo_zmax,  
	
	double *elem_d_topo_edge0,
	double *elem_d_topo_edge1,
	double *elem_d_topo_edge2,
	
	double *elem_d_topo_nabrdist0,
	double *elem_d_topo_nabrdist1,
	double *elem_d_topo_nabrdist2,
	
	double *elem_d_topo_nabr_x0,
	double *elem_d_topo_nabr_x1,
    double *elem_d_topo_nabr_x2,
	
	double *elem_d_topo_nabr_y0,
	double *elem_d_topo_nabr_y1,
	double *elem_d_topo_nabr_y2,   /* Topography */ 
	
    double *elem_d_soil_depth,
	double *elem_d_soil_ksath, 
	double *elem_d_soil_ksatv,     
    double *elem_d_soil_kinfv, 
	double *elem_d_soil_dinf, 
	double *elem_d_soil_alpha,     
    double *elem_d_soil_beta, 
	double *elem_d_soil_porosity, 
	double *elem_d_soil_smcmax,        
    double *elem_d_soil_smcmin,
	double *elem_d_soil_smcwlt, 
	double *elem_d_soil_smcref,    
    double *elem_d_soil_dmac, 
	double *elem_d_soil_kmach, 
	double *elem_d_soil_kmacv,  
    double *elem_d_soil_areafv, 
	double *elem_d_soil_areafh,    /* Soil parameters */
    double *elem_d_lc_shdfac, 
	double *elem_d_lc_shdmin, 
	double *elem_d_lc_shdmax,     
    double *elem_d_lc_laimin, 
	double *elem_d_lc_laimax, 
	double *elem_d_lc_snup,         
    double *elem_d_lc_cfactr, 
	double *elem_d_lc_emissmax, 
	double *elem_d_lc_emissmin,     
    double *elem_d_lc_albedomax, 
	double *elem_d_lc_albedomin, 
	double *elem_d_lc_z0max,  
    double *elem_d_lc_z0min, 
	double *elem_d_lc_rough, 
	double *elem_d_lc_cmcfactr,       
    int *elem_d_lc_bare, 
	int *elem_d_lc_isurban,     /* Land cover parameters */ 
    double *elem_d_epc_rsmin, 
	double *elem_d_epc_rgl, 
	double *elem_d_epc_hs,       
    double *elem_d_epc_topt, 
	double *elem_d_epc_rsmax,   /* Ecophysiological parameters */    
    double *elem_d_ps_rzd, 
	double *elem_d_ps_rc, 
	double *elem_d_ps_pc,                
    double *elem_d_ps_proj_lai, 
	double *elem_d_ps_rcs, 
	double *elem_d_ps_rct,        
    double *elem_d_ps_rcq, 
	double *elem_d_ps_rcsoil, 
	double *elem_d_ps_albedo,          
    double *elem_d_ps_zlvl, 
	double *elem_d_ps_zlvl_wind, 
	double *elem_d_ps_sfcspd,         
    double *elem_d_ps_rh, 
	double *elem_d_ps_sfcprs,   /* Physical states */    
    double *elem_d_ws_surf, 
	double *elem_d_ws_unsat, 
	double *elem_d_ws_gw, 
	double *elem_d_ws_sneqv,                  
    double *elem_d_ws_cmcmax,  
	double *elem_d_ws_cmc,  
	double *elem_d_ws_surfh,    /* Water states */
    double *elem_d_ws0_surf, 
	double *elem_d_ws0_unsat, 
	double *elem_d_ws0_gw,  
	double *elem_d_ws0_sneqv, 
	double *elem_d_ws0_cmcmax,                                      
    double *elem_d_ws0_cmc, 
	double *elem_d_ws0_surfh,   /* Initial Water states */	
	
    double *elem_d_wf_ovlflow0,
	double *elem_d_wf_ovlflow1,
	double *elem_d_wf_ovlflow2,
	
	double *elem_d_wf_subsurf0,
	double *elem_d_wf_subsurf1,
	double *elem_d_wf_subsurf2,
	
    double *elem_d_wf_prcp, 
	double *elem_d_wf_pcpdrp, 
	double *elem_d_wf_infil,                        
    double *elem_d_wf_rechg, 
	double *elem_d_wf_drip, 
	double *elem_d_wf_edir,                       
    double *elem_d_wf_ett, 
	double *elem_d_wf_ec, 
	double *elem_d_wf_etp,                           
    double *elem_d_wf_eta, 
	double *elem_d_wf_edir_surf, 
	double *elem_d_wf_edir_unsat,                      
    double *elem_d_wf_edir_gw, 
	double *elem_d_wf_ett_unsat, 
	double *elem_d_wf_ett_gw,                     
    double *elem_d_wf_esnow,          /* Water fluxes */         
    double *elem_d_es_sfctmp,         /* Energy states */
    double *elem_d_ef_soldn,          /* Energy fluxes */ 
	
	double *elem_d_bc_head0,
	double *elem_d_bc_head1,
	double *elem_d_bc_head2,
	
	double *elem_d_bc_flux0,
	double *elem_d_bc_flux1,
	double *elem_d_bc_flux2,    /* Boundary conditions */
	
	int *elem_d_node0,
	int *elem_d_node1,
	int *elem_d_node2,
	
	int *elem_d_nabr0,
	int *elem_d_nabr1,
	int *elem_d_nabr2,
	
	int *elem_d_ind,    /* Elements' geometric numbers */    
	
/* river_d related arguments */           
    int *river_d_attrib_riverbc_type, /* River attribute */
    double *river_d_topo_area, 
	double *river_d_topo_x, 
	double *river_d_topo_y,                 
    double *river_d_topo_zmin,
	double *river_d_topo_zmax, 
	double *river_d_topo_zbed,                            
    double *river_d_topo_node_zmax, 
	double *river_d_topo_dist_left, 
	double *river_d_topo_dist_right, /* River topography parameters */   
    double *river_d_ws_stage, 
	double *river_d_ws_gw,           /* River water states */
	
	double *river_d_wf_rivflow0,
	double *river_d_wf_rivflow1,
	double *river_d_wf_rivflow2,
	double *river_d_wf_rivflow3,	
	double *river_d_wf_rivflow4,
	double *river_d_wf_rivflow5,
	double *river_d_wf_rivflow6,
	double *river_d_wf_rivflow7,
	double *river_d_wf_rivflow8,
	double *river_d_wf_rivflow9,
	double *river_d_wf_rivflow10,   /* River water fluxes */   

    double *river_d_shp_depth, 
	int    *river_d_shp_intrpl_ord,  
	double *river_d_shp_coeff,     
    double *river_d_shp_length, 
	double *river_d_shp_width,       /* River shape parameters */     
    double *river_d_matl_rough, 
	double *river_d_matl_cwr, 
	double *river_d_matl_ksath,         
    double *river_d_matl_ksatv, 
	double *river_d_matl_bedthick, 
	double *river_d_matl_porosity,     
    double *river_d_matl_smcmin, /* River mathmatic modeling */	
    double *river_d_bc_head, 
	double *river_d_bc_flux,  /* River boundary conditions */  
    int *river_d_ind, 
	int *river_d_leftele, 
	int *river_d_rightele,      
    int *river_d_fromnode, 
	int *river_d_tonode, 
	int *river_d_down  /* River geometric numbers */	