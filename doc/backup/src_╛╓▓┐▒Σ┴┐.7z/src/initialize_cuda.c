#include "pihm.h"
#include "pihm.cuh"

cudaError_t Initialize_cuda(pihm_struct_d pihm_d, 
	                        elem_struct_d *elem_d, river_struct_d *river_d,
							calib_struct_d *cal_d, ctrl_struct_d *ctrl_d)
{
	int  i;
	cudaError_t cudaStatus;
	unsigned int  flags = cudaMemAttachGlobal;   // or cudaMemAttachHost

	// ȫ������Ϊͳһ�ڴ�, "������CUDA�˺���(DOE)��������Ҫ�õ���һЩ��������" !!!
	/*
	 * Initialize PIHM structure on GPU, now we use SoA-style struct
	 */
// --------------- Basin Element ---------------------
	/* Element geometrics */
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaMallocManaged(&(elem_d->node[i]), nelem * sizeof(double), flags);
		cudaStatus = cudaMallocManaged(&(elem_d->nabr[i]), nelem * sizeof(double), flags);
	}
	cudaStatus = cudaMallocManaged(&(elem_d->ind), nelem * sizeof(double), flags);

	/* Element attribute */
	for (i = 0; i < NUM_EDGE; i++)
		cudaStatus = cudaMallocManaged(&(elem_d->attrib.bc_type[i]), nelem * sizeof(int), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->attrib.soil_type), nelem * sizeof(int), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->attrib.lc_type), nelem * sizeof(int), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->attrib.meteo_type), nelem * sizeof(int), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->attrib.lai_type), nelem * sizeof(int), flags);

	/* Topography parameters */
	cudaStatus = cudaMallocManaged(&(elem_d->topo.area), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->topo.x), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->topo.y), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->topo.zmin), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->topo.zmax), nelem * sizeof(double), flags);
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaMallocManaged(&(elem_d->topo.edge[i]), nelem * sizeof(double), flags);
		cudaStatus = cudaMallocManaged(&(elem_d->topo.nabrdist[i]), nelem * sizeof(double), flags);
		cudaStatus = cudaMallocManaged(&(elem_d->topo.nabr_x[i]), nelem * sizeof(double), flags);
		cudaStatus = cudaMallocManaged(&(elem_d->topo.nabr_y[i]), nelem * sizeof(double), flags);
	}

	/* Soil parameters  soil */
	cudaStatus = cudaMallocManaged(&(elem_d->soil.depth), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.ksath), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.ksatv), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.kinfv), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.dinf), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.alpha), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.beta), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.porosity), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.smcmax), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.smcmin), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.smcwlt), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.smcref), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.dmac), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.kmach), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.kmacv), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.areafv), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->soil.areafh), nelem * sizeof(double), flags);
		
	/* Land cover parameters */
	cudaStatus = cudaMallocManaged(&(elem_d->lc.shdfac), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.shdmin), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.shdmax), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.laimin), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.laimax), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.snup), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.cfactr), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.emissmax), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.emissmin), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.albedomax), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.albedomin), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.z0max), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.z0min), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.rough), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.cmcfactr), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.bare), nelem * sizeof(int), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->lc.isurban), nelem * sizeof(int), flags);

	/* Ecophysiological parameters */
	cudaStatus = cudaMallocManaged(&(elem_d->epc.rsmin), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->epc.rgl), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->epc.hs), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->epc.topt), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->epc.rsmax), nelem * sizeof(double), flags);

	/* Physical states  ps */
	cudaStatus = cudaMallocManaged(&(elem_d->ps.rzd), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.rc), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.pc), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.proj_lai), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.rcs), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.rct), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.rcq), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.rcsoil), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.albedo), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.zlvl), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.zlvl_wind), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.sfcspd), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.rh), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ps.sfcprs), nelem * sizeof(double), flags);

	/* Water states  ws */
	cudaStatus = cudaMallocManaged(&(elem_d->ws.surf), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws.unsat), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws.gw), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws.sneqv), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws.cmcmax), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws.cmc), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws.surfh), nelem * sizeof(double), flags);

	/* Initial Water states   ws0 */
	cudaStatus = cudaMallocManaged(&(elem_d->ws0.surf), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws0.unsat), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws0.gw), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws0.sneqv), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws0.cmcmax), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws0.cmc), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->ws0.surfh), nelem * sizeof(double), flags);

	/* Water fluxes  wf */
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaMallocManaged(&(elem_d->wf.ovlflow[i]), nelem * sizeof(double), flags);
		cudaStatus = cudaMallocManaged(&(elem_d->wf.subsurf[i]), nelem * sizeof(double), flags);
	}
	cudaStatus = cudaMallocManaged(&(elem_d->wf.prcp), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.pcpdrp), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.infil), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.rechg), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.drip), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.edir), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.ett), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.ec), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.etp), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.eta), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.edir_surf), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.edir_unsat), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.edir_gw), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.ett_unsat), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.ett_gw), nelem * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(elem_d->wf.esnow), nelem * sizeof(double), flags);
	
	/* Energy states */
	cudaStatus = cudaMallocManaged(&(elem_d->es.sfctmp), nelem * sizeof(double), flags);

	/* Energy fluxes */
	cudaStatus = cudaMallocManaged(&(elem_d->ef.soldn), nelem * sizeof(double), flags);

	/* Boundary conditions */
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaMallocManaged(&(elem_d->bc.head[i]), nelem * sizeof(double), flags);
		cudaStatus = cudaMallocManaged(&(elem_d->bc.flux[i]), nelem * sizeof(double), flags);
	}

	// Check cudaMallocManaged Status
	if (cudaStatus != cudaSuccess) {
		fprintf(stderr, "Element: cudaMallocManaged failed! Check Initialize_CUDA ?\n");
		exit(cudaStatus);
	}
//------------- River Segments -------------------
	/* River geometrics */
	cudaStatus = cudaMallocManaged(&(river_d->ind), nriver * sizeof(int), flags);
	cudaStatus = cudaMallocManaged(&(river_d->leftele), nriver * sizeof(int), flags);
	cudaStatus = cudaMallocManaged(&(river_d->rightele), nriver * sizeof(int), flags);
	cudaStatus = cudaMallocManaged(&(river_d->fromnode), nriver * sizeof(int), flags);
	cudaStatus = cudaMallocManaged(&(river_d->tonode), nriver * sizeof(int), flags);
	cudaStatus = cudaMallocManaged(&(river_d->down), nriver * sizeof(int), flags);

	/* River attribute */
	cudaStatus = cudaMallocManaged(&(river_d->attrib.riverbc_type), nriver * sizeof(double), flags);

	/* River topography parameters */
	cudaStatus = cudaMallocManaged(&(river_d->topo.area), nriver * sizeof(double), flags);	
	cudaStatus = cudaMallocManaged(&(river_d->topo.x), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->topo.y), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->topo.zmin), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->topo.zmax), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->topo.zbed), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->topo.node_zmax), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->topo.dist_left), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->topo.dist_right), nriver * sizeof(double), flags);

	/* River water states */
	cudaStatus = cudaMallocManaged(&(river_d->ws.stage), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->ws.gw), nriver * sizeof(double), flags);
	
	/* River water fluxes */
	for (i = 0; i < NUM_RIVFLX; i++)
		cudaStatus = cudaMallocManaged(&(river_d->wf.rivflow[i]), nriver * sizeof(double), flags);

	/* River shape parameters */
	cudaStatus = cudaMallocManaged(&(river_d->shp.depth), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->shp.intrpl_ord), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->shp.coeff), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->shp.length), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->shp.width), nriver * sizeof(double), flags);

	/* matl_struct_d */
	cudaStatus = cudaMallocManaged(&(river_d->matl.rough), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->matl.cwr), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->matl.ksath), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->matl.ksatv), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->matl.bedthick), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->matl.porosity), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->matl.smcmin), nriver * sizeof(double), flags);

	/* River boundary conditions */
	cudaStatus = cudaMallocManaged(&(river_d->bc.head), nriver * sizeof(double), flags);
	cudaStatus = cudaMallocManaged(&(river_d->bc.flux), nriver * sizeof(double), flags);

	// check the CUDA allocation status
	cudaStatus = cudaSetDevice(0);
	if (cudaStatus != cudaSuccess) {
		fprintf(stderr, "River: cudaMallocManaged failed! Check Initialize_CUDA ?\n");
		exit(cudaStatus);
	}	

	// Transfer other parameters into GPU, like calib_struct, ctrl_struct etc.
	/* Global calibration coefficients */
	cudaStatus = cudaMalloc((void **)&cal_d->ec, sizeof(double));
	cudaStatus = cudaMalloc((void **)&cal_d->ett, sizeof(double));
	cudaStatus = cudaMalloc((void **)&cal_d->edir, sizeof(double));

	/* Model control parameters */
	cudaStatus = cudaMalloc((void **)&ctrl_d->stepsize, sizeof(int));
	cudaStatus = cudaMalloc((void **)&ctrl_d->surf_mode, sizeof(int));
	cudaStatus = cudaMalloc((void **)&ctrl_d->riv_mode, sizeof(int));
	cudaStatus = cudaMalloc((void **)&ctrl_d->etstep, sizeof(int));

	return(cudaStatus);
}

/* ���GPU��SoA���Ľṹ��ռ����󣬽�CPU��AoS���Ľṹ�����ݣ�
 * ������GPU�豸��, ����ʹ��OpenMP���߳̿���.
 */
void AoS_to_SoA(pihm_struct pihm, pihm_struct_d pihm_d,
	            elem_struct_d *elem_d, river_struct_d *river_d,
				calib_struct_d *cal_d, ctrl_struct_d *ctrl_d)
{
	int   i, tid;

// ���ݽṹ���еı���˳�򣬿�ʼת����ֵ, AoS --> SoA

	/* Variables related with basin elements */
#if defined(_OPENMP)
# pragma omp parallel for
#endif
	for (tid = 0; tid < nelem; tid++){

	   /* Element geometrics in GPU */
		for (i = 0; i < NUM_EDGE; i++){
			elem_d->node[i][tid] = pihm->elem[tid].node[i];
			elem_d->nabr[i][tid] = pihm->elem[tid].nabr[i];
		}
		elem_d->ind[tid] = pihm->elem[tid].ind;

		/* Element attribute */
		for (i = 0; i < NUM_EDGE; i++)
			elem_d->attrib.bc_type[i][tid] = pihm->elem[tid].attrib.bc_type[i];
		elem_d->attrib.soil_type[tid] = pihm->elem[tid].attrib.soil_type;
		elem_d->attrib.lc_type[tid] = pihm->elem[tid].attrib.lc_type;
		elem_d->attrib.meteo_type[tid] = pihm->elem[tid].attrib.meteo_type;
		elem_d->attrib.lai_type[tid] = pihm->elem[tid].attrib.lai_type;

		/* Topography parameters */
		elem_d->topo.area[tid] = pihm->elem[tid].topo.area;
		elem_d->topo.x[tid] = pihm->elem[tid].topo.x;
		elem_d->topo.y[tid] = pihm->elem[tid].topo.y;
		elem_d->topo.zmin[tid] = pihm->elem[tid].topo.zmin;
		elem_d->topo.zmax[tid] = pihm->elem[tid].topo.zmax;
		for (i = 0; i < NUM_EDGE; i++){
			elem_d->topo.edge[i][tid] = pihm->elem[tid].topo.edge[i];
			elem_d->topo.nabrdist[i][tid] = pihm->elem[tid].topo.nabrdist[i];
			elem_d->topo.nabr_x[i][tid] = pihm->elem[tid].topo.nabr_x[i];
			elem_d->topo.nabr_y[i][tid] = pihm->elem[tid].topo.nabr_y[i];
		}

		/* Soil parameters */
		elem_d->soil.depth[tid] = pihm->elem[tid].soil.depth;
		elem_d->soil.ksath[tid] = pihm->elem[tid].soil.ksath;
		elem_d->soil.ksatv[tid] = pihm->elem[tid].soil.ksatv;
		elem_d->soil.kinfv[tid] = pihm->elem[tid].soil.kinfv;
		elem_d->soil.dinf[tid] = pihm->elem[tid].soil.dinf;
		elem_d->soil.alpha[tid] = pihm->elem[tid].soil.alpha;
		elem_d->soil.beta[tid] = pihm->elem[tid].soil.beta;
		elem_d->soil.porosity[tid] = pihm->elem[tid].soil.porosity;	
		elem_d->soil.smcmax[tid] = pihm->elem[tid].soil.smcmax;
		elem_d->soil.smcmin[tid] = pihm->elem[tid].soil.smcmin;
		elem_d->soil.smcwlt[tid] = pihm->elem[tid].soil.smcwlt;
		elem_d->soil.smcref[tid] = pihm->elem[tid].soil.smcref;
		elem_d->soil.dmac[tid] = pihm->elem[tid].soil.dmac;
		elem_d->soil.kmach[tid] = pihm->elem[tid].soil.kmach;
		elem_d->soil.kmacv[tid] = pihm->elem[tid].soil.kmacv;
		elem_d->soil.areafv[tid] = pihm->elem[tid].soil.areafv;
		elem_d->soil.areafh[tid] = pihm->elem[tid].soil.areafh;
		
		/* Land cover parameters */
		elem_d->lc.shdfac[tid] = pihm->elem[tid].lc.shdfac;
		elem_d->lc.shdmin[tid] = pihm->elem[tid].lc.shdmin;
		elem_d->lc.shdmax[tid] = pihm->elem[tid].lc.shdmax;
		elem_d->lc.laimin[tid] = pihm->elem[tid].lc.laimin;
		elem_d->lc.laimax[tid] = pihm->elem[tid].lc.laimax;
		elem_d->lc.snup[tid] = pihm->elem[tid].lc.snup;
		elem_d->lc.cfactr[tid] = pihm->elem[tid].lc.cfactr;
		elem_d->lc.emissmax[tid] = pihm->elem[tid].lc.emissmax;
		elem_d->lc.emissmin[tid] = pihm->elem[tid].lc.emissmin;
		elem_d->lc.albedomax[tid] = pihm->elem[tid].lc.albedomax;
		elem_d->lc.albedomin[tid] = pihm->elem[tid].lc.albedomin;
		elem_d->lc.z0max[tid] = pihm->elem[tid].lc.z0max;
		elem_d->lc.z0min[tid] = pihm->elem[tid].lc.z0min;
		elem_d->lc.rough[tid] = pihm->elem[tid].lc.rough;
		elem_d->lc.cmcfactr[tid] = pihm->elem[tid].lc.cmcfactr;
		elem_d->lc.bare[tid] = pihm->elem[tid].lc.bare;
		elem_d->lc.isurban[tid] = pihm->elem[tid].lc.isurban;

		/* Ecophysiological parameters */
		elem_d->epc.rsmin[tid] = pihm->elem[tid].epc.rsmin;
		elem_d->epc.rgl[tid] = pihm->elem[tid].epc.rgl;
		elem_d->epc.hs[tid] = pihm->elem[tid].epc.hs;
		elem_d->epc.topt[tid] = pihm->elem[tid].epc.topt;
		elem_d->epc.rsmax[tid] = pihm->elem[tid].epc.rsmax;

		/* Physical states  ps */
		elem_d->ps.rzd[tid] = pihm->elem[tid].ps.rzd;
		elem_d->ps.rc[tid] = pihm->elem[tid].ps.rc;
		elem_d->ps.pc[tid] = pihm->elem[tid].ps.pc;
		elem_d->ps.proj_lai[tid] = pihm->elem[tid].ps.proj_lai;
		elem_d->ps.rcs[tid] = pihm->elem[tid].ps.rcs;
		elem_d->ps.rct[tid] = pihm->elem[tid].ps.rct;
		elem_d->ps.rcq[tid] = pihm->elem[tid].ps.rcq;
		elem_d->ps.rcsoil[tid] = pihm->elem[tid].ps.rcsoil;
		elem_d->ps.albedo[tid] = pihm->elem[tid].ps.albedo;
		elem_d->ps.zlvl[tid] = pihm->elem[tid].ps.zlvl;
		elem_d->ps.zlvl_wind[tid] = pihm->elem[tid].ps.zlvl_wind;
		elem_d->ps.sfcspd[tid] = pihm->elem[tid].ps.sfcspd;
		elem_d->ps.rh[tid] = pihm->elem[tid].ps.rh;
		elem_d->ps.sfcprs[tid] = pihm->elem[tid].ps.sfcprs;

		/* Water states  ws */
		elem_d->ws.surf[tid] = pihm->elem[tid].ws.surf;
		elem_d->ws.unsat[tid] = pihm->elem[tid].ws.unsat;
		elem_d->ws.gw[tid] = pihm->elem[tid].ws.gw;
		elem_d->ws.sneqv[tid] = pihm->elem[tid].ws.sneqv;
		elem_d->ws.cmcmax[tid] = pihm->elem[tid].ws.cmcmax;
		elem_d->ws.cmc[tid] = pihm->elem[tid].ws.cmc;
		elem_d->ws.surfh[tid] = pihm->elem[tid].ws.surfh;

		/* Initial Water states  ws0 */
		elem_d->ws0.surf[tid] = pihm->elem[tid].ws0.surf;
		elem_d->ws0.unsat[tid] = pihm->elem[tid].ws0.unsat;
		elem_d->ws0.gw[tid] = pihm->elem[tid].ws0.gw;
		elem_d->ws0.sneqv[tid] = pihm->elem[tid].ws0.sneqv;
		elem_d->ws0.cmcmax[tid] = pihm->elem[tid].ws0.cmcmax;
		elem_d->ws0.cmc[tid] = pihm->elem[tid].ws0.cmc;
		elem_d->ws0.surfh[tid] = pihm->elem[tid].ws0.surfh;

		/* Water fluxes  wf */
		for (i = 0; i < NUM_EDGE; i++){
			elem_d->wf.ovlflow[i][tid] = pihm->elem[tid].wf.ovlflow[i];
			elem_d->wf.subsurf[i][tid] = pihm->elem[tid].wf.subsurf[i];
		}
		elem_d->wf.prcp[tid] = pihm->elem[tid].wf.prcp;
		elem_d->wf.pcpdrp[tid] = pihm->elem[tid].wf.pcpdrp;
		elem_d->wf.infil[tid] = pihm->elem[tid].wf.infil;
		elem_d->wf.rechg[tid] = pihm->elem[tid].wf.rechg;
		elem_d->wf.drip[tid] = pihm->elem[tid].wf.drip;
		elem_d->wf.edir[tid] = pihm->elem[tid].wf.edir;
		elem_d->wf.ett[tid] = pihm->elem[tid].wf.ett;
		elem_d->wf.ec[tid] = pihm->elem[tid].wf.ec;
		elem_d->wf.etp[tid] = pihm->elem[tid].wf.etp;
		elem_d->wf.eta[tid] = pihm->elem[tid].wf.eta;
		elem_d->wf.edir_surf[tid] = pihm->elem[tid].wf.edir_surf;
		elem_d->wf.edir_unsat[tid] = pihm->elem[tid].wf.edir_unsat;
		elem_d->wf.edir_gw[tid] = pihm->elem[tid].wf.edir_gw;
		elem_d->wf.ett_unsat[tid] = pihm->elem[tid].wf.ett_unsat;
		elem_d->wf.ett_gw[tid] = pihm->elem[tid].wf.ett_gw;
		elem_d->wf.esnow[tid] = pihm->elem[tid].wf.esnow;

		/* Energy states */
		elem_d->es.sfctmp[tid] = pihm->elem[tid].es.sfctmp;

		/* Energy fluxes */
		elem_d->ef.soldn[tid] = pihm->elem[tid].ef.soldn;

		/* Boundary conditions */
		for (i = 0; i < NUM_EDGE; i++){
			elem_d->bc.flux[i][tid] = pihm->elem[tid].bc.flux[i];
			elem_d->bc.head[i][tid] = pihm->elem[tid].bc.head[i];
		}

	}  // for (tid = 0; tid < nelem; tid++)
	printf("Element: Transfer AoS on CPU into SoA on GPU!\n\n");

	/* Variables related with basin elements */
#if defined(_OPENMP)
# pragma omp parallel for
#endif
	for (tid = 0; tid < nriver; tid++){

		/* River geometrics */
		river_d->ind[tid] = pihm->river[tid].ind;
		river_d->leftele[tid] = pihm->river[tid].leftele;
		river_d->rightele[tid] = pihm->river[tid].rightele;
		river_d->fromnode[tid] = pihm->river[tid].fromnode;
		river_d->tonode[tid] = pihm->river[tid].tonode;
		river_d->down[tid] = pihm->river[tid].down;

		/* River attribute */
		river_d->attrib.riverbc_type[tid] = pihm->river[tid].attrib.riverbc_type;
		
		/* River topography parameters */
		river_d->topo.area[tid] = pihm->river[tid].topo.area;
		river_d->topo.x[tid] = pihm->river[tid].topo.x;
	    river_d->topo.y[tid] = pihm->river[tid].topo.y;
		river_d->topo.zmin[tid] = pihm->river[tid].topo.zmin;
		river_d->topo.zmax[tid] = pihm->river[tid].topo.zmax;
		river_d->topo.zbed[tid] = pihm->river[tid].topo.zbed;
		river_d->topo.node_zmax[tid] = pihm->river[tid].topo.node_zmax;
		river_d->topo.dist_left[tid] = pihm->river[tid].topo.dist_left;
		river_d->topo.dist_right[tid] = pihm->river[tid].topo.dist_right;
	
		/* River water states */
		river_d->ws.stage[tid] = pihm->river[tid].ws.stage;
		river_d->ws.gw[tid] = pihm->river[tid].ws.gw;

		/* River water fluxes */
		for (i = 0; i < NUM_RIVFLX; i++)
			river_d->wf.rivflow[i][tid] = pihm->river[tid].wf.rivflow[i];

		/* River shape parameters */
		river_d->shp.depth[tid] = pihm->river[tid].shp.depth;
		river_d->shp.intrpl_ord[tid] = pihm->river[tid].shp.intrpl_ord;
		river_d->shp.coeff[tid] = pihm->river[tid].shp.coeff;
		river_d->shp.length[tid] = pihm->river[tid].shp.length;
		river_d->shp.width[tid] = pihm->river[tid].shp.width;

		/* matl_struct_d */
		river_d->matl.rough[tid] = pihm->river[tid].matl.rough;
		river_d->matl.cwr[tid] = pihm->river[tid].matl.cwr;
		river_d->matl.ksath[tid] = pihm->river[tid].matl.ksath;
		river_d->matl.ksatv[tid] = pihm->river[tid].matl.ksatv;
		river_d->matl.bedthick[tid] = pihm->river[tid].matl.bedthick;
		river_d->matl.porosity[tid] = pihm->river[tid].matl.porosity;
		river_d->matl.smcmin[tid] = pihm->river[tid].matl.smcmin;

		/* River boundary conditions */
		river_d->bc.head[tid] = pihm->river[tid].bc.head;
		river_d->bc.flux[tid] = pihm->river[tid].bc.flux;

	}  // for (i = 0; i < nriver; i++)
	printf("River: Transfer AoS on CPU into SoA on GPU!\n\n");

	// Transfer other parameters into GPU, like calib_struct, ctrl_struct etc.
	/* Global calibration coefficients */
	cudaMemcpy(&cal_d->ec, &pihm->cal.ec, sizeof(double), cudaMemcpyHostToDevice);
	cudaMemcpy(&cal_d->ett, &pihm->cal.ett, sizeof(double), cudaMemcpyHostToDevice);
	cudaMemcpy(&cal_d->edir, &pihm->cal.edir, sizeof(double), cudaMemcpyHostToDevice);

	/* Model control parameters */
	cudaMemcpy(&ctrl_d->stepsize, &pihm->ctrl.stepsize, sizeof(int), cudaMemcpyHostToDevice);
	cudaMemcpy(&ctrl_d->surf_mode, &pihm->ctrl.surf_mode, sizeof(int), cudaMemcpyHostToDevice);
	cudaMemcpy(&ctrl_d->riv_mode, &pihm->ctrl.riv_mode, sizeof(int), cudaMemcpyHostToDevice);
	cudaMemcpy(&ctrl_d->etstep, &pihm->ctrl.etstep, sizeof(int), cudaMemcpyHostToDevice);


}