#include "pihm.h"
#include "pihm.cuh"

cudaError_t FreeMem_cuda(pihm_struct_d pihm_d, elem_struct_d *elem_d, river_struct_d *river_d)
{
	int             i;
	cudaError_t cudaStatus;

// --------------- Basin Element ---------------------
	/* Element geometrics */
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaFree(elem_d->node[i]);
		cudaStatus = cudaFree(elem_d->nabr[i]);	
	}
	cudaStatus = cudaFree(elem_d->ind);

	/* Element attribute */
	for (i = 0; i < NUM_EDGE; i++)
		cudaStatus = cudaFree(elem_d->attrib.bc_type[i]);



	/* Topography parameters */
	cudaStatus = cudaFree(elem_d->topo.area);
	cudaStatus = cudaFree(elem_d->topo.x);
	cudaStatus = cudaFree(elem_d->topo.y);
	cudaStatus = cudaFree(elem_d->topo.zmin);
	cudaStatus = cudaFree(elem_d->topo.zmax);
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaFree(elem_d->topo.edge[i]);
		cudaStatus = cudaFree(elem_d->topo.nabrdist[i]);
		cudaStatus = cudaFree(elem_d->topo.nabr_x[i]);
		cudaStatus = cudaFree(elem_d->topo.nabr_y[i]);
	}

	/* Soil parameters  soil */
	cudaStatus = cudaFree(elem_d->soil.depth);
	cudaStatus = cudaFree(elem_d->soil.ksath);
	cudaStatus = cudaFree(elem_d->soil.dinf);
	cudaStatus = cudaFree(elem_d->soil.dmac);
	cudaStatus = cudaFree(elem_d->soil.kmach);
	cudaStatus = cudaFree(elem_d->soil.areafv);
	cudaStatus = cudaFree(elem_d->soil.porosity);

	/* Land cover parameters */
	cudaStatus = cudaFree(elem_d->lc.rough);




	/* Physical states  ps */
	cudaStatus = cudaFree(elem_d->ps.rzd);





	/* Water states  ws */
	cudaStatus = cudaFree(elem_d->ws.surf);
	cudaStatus = cudaFree(elem_d->ws.unsat);
	cudaStatus = cudaFree(elem_d->ws.gw);
	cudaStatus = cudaFree(elem_d->ws.sneqv);
	cudaStatus = cudaFree(elem_d->ws.cmcmax);
	cudaStatus = cudaFree(elem_d->ws.cmc);
	cudaStatus = cudaFree(elem_d->ws.surfh);
	/* Water fluxes  ws0 */
	cudaStatus = cudaFree(elem_d->ws0.surf);

	/* Water fluxes  wf */
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaFree(elem_d->wf.ovlflow[i]);
		cudaStatus = cudaFree(elem_d->wf.subsurf[i]);
	}
	cudaStatus = cudaFree(elem_d->wf.prcp);
	cudaStatus = cudaFree(elem_d->wf.pcpdrp);
	cudaStatus = cudaFree(elem_d->wf.infil);
	cudaStatus = cudaFree(elem_d->wf.rechg);
	cudaStatus = cudaFree(elem_d->wf.drip);
	cudaStatus = cudaFree(elem_d->wf.edir);
	cudaStatus = cudaFree(elem_d->wf.ett);
	cudaStatus = cudaFree(elem_d->wf.ec);
	cudaStatus = cudaFree(elem_d->wf.etp);
	cudaStatus = cudaFree(elem_d->wf.eta);
	cudaStatus = cudaFree(elem_d->wf.edir_surf);
	cudaStatus = cudaFree(elem_d->wf.edir_unsat);
	cudaStatus = cudaFree(elem_d->wf.edir_gw);
	cudaStatus = cudaFree(elem_d->wf.ett_unsat);
	cudaStatus = cudaFree(elem_d->wf.ett_gw);
	cudaStatus = cudaFree(elem_d->wf.esnow);

	/* Boundary conditions */
	for (i = 0; i < NUM_EDGE; i++){
		cudaStatus = cudaFree(elem_d->bc.head[i]);
		cudaStatus = cudaFree(elem_d->bc.flux[i]);
	}

	if (cudaStatus != cudaSuccess) {
		fprintf(stderr, "Element: cudaFree failed! Check Free_CUDA ?\n");
		exit(cudaStatus);
	}
//------------- River Segments -------------------
		/* River attribute */
		cudaStatus = cudaFree(river_d->attrib.riverbc_type);

		/* River topography parameters */
		cudaStatus = cudaFree(river_d->topo.area);
		//cudaStatus = cudaFree(river_d->topo.x);
		//cudaStatus = cudaFree(river_d->topo.y);
		cudaStatus = cudaFree(river_d->topo.zmin);
		cudaStatus = cudaFree(river_d->topo.zmax);
		cudaStatus = cudaFree(river_d->topo.zbed);
		//cudaStatus = cudaFree(river_d->topo.node_zmax);
		cudaStatus = cudaFree(river_d->topo.dist_left);
		cudaStatus = cudaFree(river_d->topo.dist_right);

		/* River water states */
		cudaStatus = cudaFree(river_d->ws.stage);
		cudaStatus = cudaFree(river_d->ws.gw);

		/* River water fluxes */
		for (i = 0; i < NUM_RIVFLX; i++)
			cudaStatus = cudaFree(river_d->wf.rivflow[i]);

		/* River shape parameters */
		cudaStatus = cudaFree(river_d->shp.depth);
		cudaStatus = cudaFree(river_d->shp.intrpl_ord);
		cudaStatus = cudaFree(river_d->shp.coeff);
		cudaStatus = cudaFree(river_d->shp.length);
		cudaStatus = cudaFree(river_d->shp.width);

		/* matl_struct_d */
		cudaStatus = cudaFree(river_d->matl.rough);
		cudaStatus = cudaFree(river_d->matl.cwr);
		cudaStatus = cudaFree(river_d->matl.ksath);
		//cudaStatus = cudaFree(river_d->matl.ksatv);
		//cudaStatus = cudaFree(river_d->matl.bedthick);
		cudaStatus = cudaFree(river_d->matl.porosity);
		//cudaStatus = cudaFree(river_d->matl.smcmin);

		/* River boundary conditions */
		cudaStatus = cudaFree(river_d->bc.head);
		cudaStatus = cudaFree(river_d->bc.flux);








		// check the CUDA allocation status
		cudaStatus = cudaSetDevice(0);
		if (cudaStatus != cudaSuccess) {
			fprintf(stderr, "River: cudaFree failed! Check Free_CUDA ?\n");
			exit(cudaStatus);
		}
		return(cudaStatus);
}