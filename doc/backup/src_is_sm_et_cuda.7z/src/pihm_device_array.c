/* elem_d related arguments */
    int *elem_d_attrib_soil_type; 
	int *elem_d_attrib_lc_type;             
    int *elem_d_attrib_bc_type[NUM_EDGE];
	int *elem_d_attrib_meteo_type; 
	int *elem_d_attrib_lai_type;   /* Element attribute */          
    realtype *elem_d_topo_area; 
	realtype *elem_d_topo_x; 
	realtype *elem_d_topo_y;                               
    realtype *elem_d_topo_zmin; 
	realtype *elem_d_topo_zmax;                                
	realtype *elem_d_topo_edge[NUM_EDGE]; 
	realtype *elem_d_topo_nabrdist[NUM_EDGE];        
    realtype *elem_d_topo_nabr_x[NUM_EDGE]; 
	realtype *elem_d_topo_nabr_y[NUM_EDGE]; /* Topography */                 
    realtype *elem_d_soil_depth;
	realtype *elem_d_soil_ksath; 
	realtype *elem_d_soil_ksatv;     
    realtype *elem_d_soil_kinfv; 
	realtype *elem_d_soil_dinf; 
	realtype *elem_d_soil_alpha;     
    realtype *elem_d_soil_beta; 
	realtype *elem_d_soil_porosity; 
	realtype *elem_d_soil_smcmax;        
    realtype *elem_d_soil_smcmin;
	realtype *elem_d_soil_smcwlt; 
	realtype *elem_d_soil_smcref;    
    realtype *elem_d_soil_dmac; 
	realtype *elem_d_soil_kmach; 
	realtype *elem_d_soil_kmacv;  
    realtype *elem_d_soil_areafv; 
	realtype *elem_d_soil_areafh;  /* Soil parameters */
    realtype *elem_d_lc_shdfac; 
	realtype *elem_d_lc_shdmin; 
	realtype *elem_d_lc_shdmax;     
    realtype *elem_d_lc_laimin; 
	realtype *elem_d_lc_laimax; 
	realtype *elem_d_lc_snup;         
    realtype *elem_d_lc_cfactr; 
	realtype *elem_d_lc_emissmax; 
	realtype *elem_d_lc_emissmin;     
    realtype *elem_d_lc_albedomax; 
	realtype *elem_d_lc_albedomin; 
	realtype *elem_d_lc_z0max;  
    realtype *elem_d_lc_z0min; 
	realtype *elem_d_lc_rough; 
	realtype *elem_d_lc_cmcfactr;       
    int *elem_d_lc_bare; 
	int *elem_d_lc_isurban;   /* Land cover parameters */ 
    realtype *elem_d_epc_rsmin; 
	realtype *elem_d_epc_rgl; 
	realtype *elem_d_epc_hs;       
    realtype *elem_d_epc_topt; 
	realtype *elem_d_epc_rsmax;  /* Ecophysiological parameters */    
    realtype *elem_d_ps_rzd; 
	realtype *elem_d_ps_rc; 
	realtype *elem_d_ps_pc;                
    realtype *elem_d_ps_proj_lai; 
	realtype *elem_d_ps_rcs; 
	realtype *elem_d_ps_rct;        
    realtype *elem_d_ps_rcq; 
	realtype *elem_d_ps_rcsoil; 
	realtype *elem_d_ps_albedo;          
    realtype *elem_d_ps_zlvl; 
	realtype *elem_d_ps_zlvl_wind; 
	realtype *elem_d_ps_sfcspd;         
    realtype *elem_d_ps_rh; 
	realtype *elem_d_ps_sfcprs;  /* Physical states */    
    realtype *elem_d_ws_surf; 
	realtype *elem_d_ws_unsat; 
	realtype *elem_d_ws_gw; 
	realtype *elem_d_ws_sneqv;                  
    realtype *elem_d_ws_cmcmax;  
	realtype *elem_d_ws_cmc;  
	realtype *elem_d_ws_surfh;  /* Water states */
	realtype *elem_d_ws0_surf; 
	realtype *elem_d_ws0_unsat; 
	realtype *elem_d_ws0_gw;  
	realtype *elem_d_ws0_sneqv; 
	realtype *elem_d_ws0_cmcmax;
    realtype *elem_d_ws0_cmc; 
	realtype *elem_d_ws0_surfh;   /* Initial Water states */	     
    realtype *elem_d_wf_ovlflow[NUM_EDGE]; 
	realtype *elem_d_wf_subsurf[NUM_EDGE];   
    realtype *elem_d_wf_prcp; 
	realtype *elem_d_wf_pcpdrp; 
	realtype *elem_d_wf_infil;                        
    realtype *elem_d_wf_rechg; 
	realtype *elem_d_wf_drip; 
	realtype *elem_d_wf_edir;                       
    realtype *elem_d_wf_ett; 
	realtype *elem_d_wf_ec; 
	realtype *elem_d_wf_etp;                           
    realtype *elem_d_wf_eta; 
	realtype *elem_d_wf_edir_surf; 
	realtype *elem_d_wf_edir_unsat;                      
    realtype *elem_d_wf_edir_gw; 
	realtype *elem_d_wf_ett_unsat; 
	realtype *elem_d_wf_ett_gw;                     
    realtype *elem_d_wf_esnow;          /* Water fluxes */         
    realtype *elem_d_es_sfctmp;         /* Energy states */
    realtype *elem_d_ef_soldn;          /* Energy fluxes */ 
    realtype *elem_d_bc_head[NUM_EDGE]; 
	realtype *elem_d_bc_flux[NUM_EDGE]; /* Boundary conditions */
    int *elem_d_node[NUM_EDGE]; 
	int *elem_d_nabr[NUM_EDGE]; 
	int *elem_d_ind;     /* Elements' geometric numbers */  	
/* river_d related arguments */           
    int *river_d_attrib_riverbc_type;    /* River attribute */
    realtype *river_d_topo_area; 
	realtype *river_d_topo_x; 
	realtype *river_d_topo_y;                 
    realtype *river_d_topo_zmin;
	realtype *river_d_topo_zmax; 
	realtype *river_d_topo_zbed;                            
    realtype *river_d_topo_node_zmax; 
	realtype *river_d_topo_dist_left; 
	realtype *river_d_topo_dist_right;    /* River topography */   
    realtype *river_d_ws_stage; 
	realtype *river_d_ws_gw;              /* River water states */
    realtype *river_d_wf_rivflow[NUM_RIVFLX];  /* River water fluxes */   
    realtype *river_d_shp_depth; 
	int    *river_d_shp_intrpl_ord;  
	realtype *river_d_shp_coeff;     
    realtype *river_d_shp_length; 
	realtype *river_d_shp_width;       /* River shape parameters */     
    realtype *river_d_matl_rough; 
	realtype *river_d_matl_cwr; 
	realtype *river_d_matl_ksath;         
    realtype *river_d_matl_ksatv; 
	realtype *river_d_matl_bedthick; 
	realtype *river_d_matl_porosity;     
    realtype *river_d_matl_smcmin;   /* River mathmatic parameters */	
    realtype *river_d_bc_head; 
	realtype *river_d_bc_flux;       /* River boundary conditions */  
    int *river_d_ind; 
	int *river_d_leftele; 
	int *river_d_rightele;      
    int *river_d_fromnode; 
	int *river_d_tonode; 
	int *river_d_down;        /* River geometric numbers */