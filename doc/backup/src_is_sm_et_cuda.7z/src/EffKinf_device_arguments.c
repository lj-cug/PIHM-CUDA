elem_d_soil_areafh,
elem_d_soil_kinfv,
elem_d_soil_kmacv
