/* elem_d related arguments */			
int *elem_d_attrib_soil_type 	        =pihm_d->elem_d_attrib_soil_type; 
int *elem_d_attrib_lc_type             	=pihm_d->elem_d_attrib_lc_type;

/* ����CVode_CUDA���õ�Ҫ�󣬽�ָ�������ַ�ֱ𸳸�һά���飬�ٴ���˺��� */
int *elem_d_attrib_bc_type0   =   pihm_d->elem_d_attrib_bc_type[0]; 
int *elem_d_attrib_bc_type1   =   pihm_d->elem_d_attrib_bc_type[1];
int *elem_d_attrib_bc_type2   =   pihm_d->elem_d_attrib_bc_type[2];	
			 
int *elem_d_attrib_meteo_type =pihm_d->elem_d_attrib_meteo_type;
int *elem_d_attrib_lai_type    =pihm_d->elem_d_attrib_lai_type;         
realtype *elem_d_topo_area 	   =pihm_d->elem_d_topo_area; 
realtype *elem_d_topo_x 	   =pihm_d->elem_d_topo_x; 
realtype *elem_d_topo_y        =pihm_d->elem_d_topo_y;
realtype *elem_d_topo_zmin 	   =pihm_d->elem_d_topo_zmin; 
realtype *elem_d_topo_zmax     =pihm_d->elem_d_topo_zmax;

realtype *elem_d_topo_edge0  = 	pihm_d->elem_d_topo_edge[0];
realtype *elem_d_topo_edge1  = 	pihm_d->elem_d_topo_edge[1];	  
realtype *elem_d_topo_edge2  = 	pihm_d->elem_d_topo_edge[2];			  
			  
realtype *elem_d_topo_nabrdist0  =   pihm_d->elem_d_topo_nabrdist[0];		  
realtype *elem_d_topo_nabrdist1  =   pihm_d->elem_d_topo_nabrdist[1];		  			  
realtype *elem_d_topo_nabrdist2  =   pihm_d->elem_d_topo_nabrdist[2];		  			  
			  
realtype *elem_d_topo_nabr_x0  = 	   pihm_d->elem_d_topo_nabr_x[0];  
realtype *elem_d_topo_nabr_x1  = 	   pihm_d->elem_d_topo_nabr_x[1];  
realtype *elem_d_topo_nabr_x2  = 	   pihm_d->elem_d_topo_nabr_x[2];  		  
		  
realtype *elem_d_topo_nabr_y0  =    pihm_d->elem_d_topo_nabr_y[0];  
realtype *elem_d_topo_nabr_y1  =    pihm_d->elem_d_topo_nabr_y[1];  		  
realtype *elem_d_topo_nabr_y2  =    pihm_d->elem_d_topo_nabr_y[2];  	
						
realtype *elem_d_soil_depth	            =pihm_d->elem_d_soil_depth; 
realtype *elem_d_soil_ksath 	            =pihm_d->elem_d_soil_ksath; 
realtype *elem_d_soil_ksatv     	        =pihm_d->elem_d_soil_ksatv;
realtype *elem_d_soil_kinfv 				=pihm_d->elem_d_soil_kinfv; 
realtype *elem_d_soil_dinf 				=pihm_d->elem_d_soil_dinf; 
realtype *elem_d_soil_alpha     			=pihm_d->elem_d_soil_alpha;
realtype *elem_d_soil_beta 				=pihm_d->elem_d_soil_beta; 
realtype *elem_d_soil_porosity 			=pihm_d->elem_d_soil_porosity; 
realtype *elem_d_soil_smcmax        		=pihm_d->elem_d_soil_smcmax;
realtype *elem_d_soil_smcmin				=pihm_d->elem_d_soil_smcmin; 
realtype *elem_d_soil_smcwlt 				=pihm_d->elem_d_soil_smcwlt; 
realtype *elem_d_soil_smcref    			=pihm_d->elem_d_soil_smcref;
realtype *elem_d_soil_dmac 				=pihm_d->elem_d_soil_dmac; 
realtype *elem_d_soil_kmach 				=pihm_d->elem_d_soil_kmach; 
realtype *elem_d_soil_kmacv  				=pihm_d->elem_d_soil_kmacv;
realtype *elem_d_soil_areafv 				=pihm_d->elem_d_soil_areafv; 
realtype *elem_d_soil_areafh    			=pihm_d->elem_d_soil_areafh;             
realtype *elem_d_lc_shdfac 				=pihm_d->elem_d_lc_shdfac; 
realtype *elem_d_lc_shdmin 				=pihm_d->elem_d_lc_shdmin; 
realtype *elem_d_lc_shdmax     			=pihm_d->elem_d_lc_shdmax;
realtype *elem_d_lc_laimin 				=pihm_d->elem_d_lc_laimin; 
realtype *elem_d_lc_laimax 				=pihm_d->elem_d_lc_laimax; 
realtype *elem_d_lc_snup         			=pihm_d->elem_d_lc_snup;
realtype *elem_d_lc_cfactr 				=pihm_d->elem_d_lc_cfactr; 
realtype *elem_d_lc_emissmax 				=pihm_d->elem_d_lc_emissmax; 
realtype *elem_d_lc_emissmin     			=pihm_d->elem_d_lc_emissmin;
realtype *elem_d_lc_albedomax 			=pihm_d->elem_d_lc_albedomax; 
realtype *elem_d_lc_albedomin 			=pihm_d->elem_d_lc_albedomin; 
realtype *elem_d_lc_z0max  				=pihm_d->elem_d_lc_z0max;
realtype *elem_d_lc_z0min 				=pihm_d->elem_d_lc_z0min; 
realtype *elem_d_lc_rough 				=pihm_d->elem_d_lc_rough; 
realtype *elem_d_lc_cmcfactr       		=pihm_d->elem_d_lc_cmcfactr;
int *elem_d_lc_bare 					=pihm_d->elem_d_lc_bare; 
int *elem_d_lc_isurban   				=pihm_d->elem_d_lc_isurban;    
realtype *elem_d_epc_rsmin 				=pihm_d->elem_d_epc_rsmin; 
realtype *elem_d_epc_rgl 					=pihm_d->elem_d_epc_rgl; 
realtype *elem_d_epc_hs       			=pihm_d->elem_d_epc_hs;
realtype *elem_d_epc_topt 				=pihm_d->elem_d_epc_topt;
realtype *elem_d_epc_rsmax  				=pihm_d->elem_d_epc_rsmax;     
realtype *elem_d_ps_rzd 					=pihm_d->elem_d_ps_rzd; 
realtype *elem_d_ps_rc 					=pihm_d->elem_d_ps_rc; 
realtype *elem_d_ps_pc                	=pihm_d->elem_d_ps_pc;
realtype *elem_d_ps_proj_lai 				=pihm_d->elem_d_ps_proj_lai; 
realtype *elem_d_ps_rcs 					=pihm_d->elem_d_ps_rcs; 
realtype *elem_d_ps_rct        			=pihm_d->elem_d_ps_rct;
realtype *elem_d_ps_rcq 					=pihm_d->elem_d_ps_rcq; 
realtype *elem_d_ps_rcsoil 				=pihm_d->elem_d_ps_rcsoil; 
realtype *elem_d_ps_albedo          		=pihm_d->elem_d_ps_albedo;
realtype *elem_d_ps_zlvl 					=pihm_d->elem_d_ps_zlvl; 
realtype *elem_d_ps_zlvl_wind 			=pihm_d->elem_d_ps_zlvl_wind; 
realtype *elem_d_ps_sfcspd         		=pihm_d->elem_d_ps_sfcspd;
realtype *elem_d_ps_rh 					=pihm_d->elem_d_ps_rh; 
realtype *elem_d_ps_sfcprs      			=pihm_d->elem_d_ps_sfcprs;       
realtype *elem_d_ws_surf 					=pihm_d->elem_d_ws_surf; 
realtype *elem_d_ws_unsat 				=pihm_d->elem_d_ws_unsat; 
realtype *elem_d_ws_gw 					=pihm_d->elem_d_ws_gw; 
realtype *elem_d_ws_sneqv                 =pihm_d->elem_d_ws_sneqv;
realtype *elem_d_ws_cmcmax  				=pihm_d->elem_d_ws_cmcmax; 
realtype *elem_d_ws_cmc  					=pihm_d->elem_d_ws_cmc; 
realtype *elem_d_ws_surfh 				=pihm_d->elem_d_ws_surfh;      
realtype *elem_d_ws0_surf 				=pihm_d->elem_d_ws0_surf; 
realtype *elem_d_ws0_unsat 				=pihm_d->elem_d_ws0_unsat; 
realtype *elem_d_ws0_gw  					=pihm_d->elem_d_ws0_gw;
realtype *elem_d_ws0_sneqv 				=pihm_d->elem_d_ws0_sneqv; 
realtype *elem_d_ws0_cmcmax               =pihm_d->elem_d_ws0_cmcmax;
realtype *elem_d_ws0_cmc 					=pihm_d->elem_d_ws0_cmc; 
realtype *elem_d_ws0_surfh        		=pihm_d->elem_d_ws0_surfh;  

realtype *elem_d_wf_ovlflow0  =  pihm_d->elem_d_wf_ovlflow[0];
realtype *elem_d_wf_ovlflow1  =  pihm_d->elem_d_wf_ovlflow[1];
realtype *elem_d_wf_ovlflow2  =  pihm_d->elem_d_wf_ovlflow[2];

realtype *elem_d_wf_subsurf0  =  pihm_d->elem_d_wf_subsurf[0];
realtype *elem_d_wf_subsurf1  =  pihm_d->elem_d_wf_subsurf[1];
realtype *elem_d_wf_subsurf2  =  pihm_d->elem_d_wf_subsurf[2];			 
			 
realtype *elem_d_wf_prcp 					=pihm_d->elem_d_wf_prcp; 
realtype *elem_d_wf_pcpdrp 				=pihm_d->elem_d_wf_pcpdrp; 
realtype *elem_d_wf_infil                 =pihm_d->elem_d_wf_infil;
realtype *elem_d_wf_rechg 				=pihm_d->elem_d_wf_rechg; 
realtype *elem_d_wf_drip 					=pihm_d->elem_d_wf_drip; 
realtype *elem_d_wf_edir                  =pihm_d->elem_d_wf_edir;
realtype *elem_d_wf_ett 					=pihm_d->elem_d_wf_ett; 
realtype *elem_d_wf_ec 					=pihm_d->elem_d_wf_ec; 
realtype *elem_d_wf_etp                   =pihm_d->elem_d_wf_etp;
realtype *elem_d_wf_eta 					=pihm_d->elem_d_wf_eta; 
realtype *elem_d_wf_edir_surf 			=pihm_d->elem_d_wf_edir_surf; 
realtype *elem_d_wf_edir_unsat            =pihm_d->elem_d_wf_edir_unsat;
realtype *elem_d_wf_edir_gw 				=pihm_d->elem_d_wf_edir_gw; 
realtype *elem_d_wf_ett_unsat 			=pihm_d->elem_d_wf_ett_unsat; 
realtype *elem_d_wf_ett_gw                =pihm_d->elem_d_wf_ett_gw;
realtype *elem_d_wf_esnow               	=pihm_d->elem_d_wf_esnow;         
realtype *elem_d_es_sfctmp         	    =pihm_d->elem_d_es_sfctmp;         
realtype *elem_d_ef_soldn         	    =pihm_d->elem_d_ef_soldn;   

realtype *elem_d_bc_head0  =  pihm_d->elem_d_bc_head[0];
realtype *elem_d_bc_head1  =  pihm_d->elem_d_bc_head[1]; 
realtype *elem_d_bc_head2  =  pihm_d->elem_d_bc_head[2];

realtype *elem_d_bc_flux0  =  pihm_d->elem_d_bc_flux[0];
realtype *elem_d_bc_flux1  =  pihm_d->elem_d_bc_flux[1];
realtype *elem_d_bc_flux2  =  pihm_d->elem_d_bc_flux[2];  

int *elem_d_node0  =  pihm_d->elem_d_node[0];
int *elem_d_node1  =  pihm_d->elem_d_node[1];
int *elem_d_node2  =  pihm_d->elem_d_node[2];

int *elem_d_nabr0  =  pihm_d->elem_d_nabr[0];
int *elem_d_nabr1  =  pihm_d->elem_d_nabr[1];
int *elem_d_nabr2  =  pihm_d->elem_d_nabr[2];
		
int *elem_d_ind 						=pihm_d->elem_d_ind; 
  
/* river_d related arguments */          		
int *river_d_attrib_riverbc_type		=pihm_d->river_d_attrib_riverbc_type;   
realtype *river_d_topo_area 				=pihm_d->river_d_topo_area; 
realtype *river_d_topo_x 					=pihm_d->river_d_topo_x; 
realtype *river_d_topo_y                 	=pihm_d->river_d_topo_y;
realtype *river_d_topo_zmin				=pihm_d->river_d_topo_zmin; 
realtype *river_d_topo_zmax 				=pihm_d->river_d_topo_zmax; 
realtype *river_d_topo_zbed               =pihm_d->river_d_topo_zbed;
realtype *river_d_topo_node_zmax 			=pihm_d->river_d_topo_node_zmax; 
realtype *river_d_topo_dist_left 			=pihm_d->river_d_topo_dist_left;
realtype *river_d_topo_dist_right 		=pihm_d->river_d_topo_dist_right;        
realtype *river_d_ws_stage 				=pihm_d->river_d_ws_stage; 
realtype *river_d_ws_gw					=pihm_d->river_d_ws_gw; 

realtype *river_d_wf_rivflow0  =  pihm_d->river_d_wf_rivflow[0];
realtype *river_d_wf_rivflow1  =  pihm_d->river_d_wf_rivflow[1];
realtype *river_d_wf_rivflow2  =  pihm_d->river_d_wf_rivflow[2];
realtype *river_d_wf_rivflow3  =  pihm_d->river_d_wf_rivflow[3];
realtype *river_d_wf_rivflow4  =  pihm_d->river_d_wf_rivflow[4];
realtype *river_d_wf_rivflow5  =  pihm_d->river_d_wf_rivflow[5];
realtype *river_d_wf_rivflow6  =  pihm_d->river_d_wf_rivflow[6];
realtype *river_d_wf_rivflow7  =  pihm_d->river_d_wf_rivflow[7];
realtype *river_d_wf_rivflow8  =  pihm_d->river_d_wf_rivflow[8];
realtype *river_d_wf_rivflow9  =  pihm_d->river_d_wf_rivflow[9];
realtype *river_d_wf_rivflow10 =  pihm_d->river_d_wf_rivflow[10];
		
realtype *river_d_shp_depth 				=pihm_d->river_d_shp_depth; 
int    *river_d_shp_intrpl_ord  		=pihm_d->river_d_shp_intrpl_ord; 
realtype *river_d_shp_coeff     			=pihm_d->river_d_shp_coeff;
realtype *river_d_shp_length 				=pihm_d->river_d_shp_length; 
realtype *river_d_shp_width         		=pihm_d->river_d_shp_width;      
realtype *river_d_matl_rough 				=pihm_d->river_d_matl_rough; 
realtype *river_d_matl_cwr 				=pihm_d->river_d_matl_cwr; 
realtype *river_d_matl_ksath         		=pihm_d->river_d_matl_ksath;
realtype *river_d_matl_ksatv 				=pihm_d->river_d_matl_ksatv; 
realtype *river_d_matl_bedthick 			=pihm_d->river_d_matl_bedthick; 
realtype *river_d_matl_porosity     		=pihm_d->river_d_matl_porosity;
realtype *river_d_matl_smcmin 			=pihm_d->river_d_matl_smcmin;      
realtype *river_d_bc_head 	  			=pihm_d->river_d_bc_head; 
realtype *river_d_bc_flux  	  			=pihm_d->river_d_bc_flux;          
int *river_d_ind 			  			=pihm_d->river_d_ind; 
int *river_d_leftele 		  			=pihm_d->river_d_leftele; 
int *river_d_rightele      	  			=pihm_d->river_d_rightele;
int *river_d_fromnode 	      			=pihm_d->river_d_fromnode; 
int *river_d_tonode 	      			=pihm_d->river_d_tonode; 
int *river_d_down  		      			=pihm_d->river_d_down; 