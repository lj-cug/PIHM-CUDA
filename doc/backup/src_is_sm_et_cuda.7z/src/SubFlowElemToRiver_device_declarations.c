realtype *elem_d_ws_gw,
realtype *elem_d_topo_zmin,
realtype *river_d_shp_length,
realtype *river_d_topo_zbed,
realtype *river_d_topo_zmin,
realtype *river_d_ws_gw