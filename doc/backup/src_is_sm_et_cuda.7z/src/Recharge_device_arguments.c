elem_d_soil_alpha,
elem_d_soil_beta,
elem_d_soil_depth,
elem_d_soil_dinf,
elem_d_ws_gw,
elem_d_ws_unsat,
elem_d_wf_infil,

// AvgKv arguments
elem_d_soil_areafh,
elem_d_soil_dmac,
elem_d_soil_kmacv,
elem_d_soil_ksatv