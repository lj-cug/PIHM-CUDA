realtype *river_d_ws_stage,
realtype *river_d_topo_zbed,
realtype *river_d_matl_rough,
realtype *river_d_shp_coeff,
realtype *river_d_shp_length,
int      *river_d_shp_intrpl_ord



