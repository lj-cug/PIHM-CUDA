realtype *elem_d_topo_zmin,
realtype *elem_d_ws_gw,
realtype *elem_d_topo_nabrdist0,
realtype *elem_d_topo_edge0,
realtype *elem_d_bc_head0,
realtype *elem_d_bc_flux0,
realtype *elem_d_wf_ovlflow0,
realtype *elem_d_wf_subsurf0,
// EffKh arguments
realtype *elem_d_soil_areafv,
realtype *elem_d_soil_depth,
realtype *elem_d_soil_dmac,
realtype *elem_d_soil_kmach,
realtype *elem_d_soil_ksath